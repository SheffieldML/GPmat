whiteKernGradX <-
function (kern, x1, x2=x1) {

  gX = array(0, c(dim(as.array(x2))[1], dim(as.array(x2))[2], dim(as.array(x1))[1]))

  return (gX)
}

