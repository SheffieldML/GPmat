multiKernExtractParam <-
function (kern, only.values=TRUE,
                                   untransformed.values=FALSE) {
  return (cmpndKernExtractParam(kern, only.values=only.values,
                                untransformed.values=untransformed.values))
}
