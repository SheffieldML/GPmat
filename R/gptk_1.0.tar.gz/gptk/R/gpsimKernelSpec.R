gpsimKernelSpec <-
function(comps, options, exps=NULL) {
  kernType <- list(type="multi", comp=list())

  if (!is.null(exps)) {
    hierkern <- list(type="cmpnd", comp=list())
    for (k in seq(1, length(exps)+1)) {
      hierkern$comp[[k]] <- list(type="multi", comp=list())
    }
  }
  
  for (i in seq_along(comps)) {
    kernType$comp[[i]] <- list(type="parametric", realType=comps[i],
                               options=options)
    if (!is.null(exps)) {
      hierkern$comp[[1]]$comp[[i]] <-
        list(type="selproj",
             comp=kernType$comp[i],
             options=list(expmask=0))
      for (k in seq_along(exps)) {
        hierkern$comp[[k+1]]$comp[[i]] <- hierkern$comp[[1]]$comp[[i]]
        hierkern$comp[[k+1]]$comp[[i]]$options$expmask <- exps[k]
        #if (i==1)
        #  hierkern$comp[[k+1]]$comp[[i]]$options$priors <- list(list(type="invgamma", params=c(0.5, 0.5), index=2))
      }
    }
  }

  if (is.null(exps)) {
    return (kernType);
  } else {
    return (hierkern);
  }
}

