kernPriorLogProb <-
function (kern) {
  L <- 0
  if (kern$type %in% c('cmpnd', 'multi', 'tensor')) {
    for (i in seq_along(kern$comp)) {
      L <- L + kernPriorLogProb(kern$comp[[i]])
    }
  } else {
    if ("priors" %in% names(kern)) {
      func <- get(paste(kern$type, 'KernExtractParam', sep=''), mode='function')
      params <- func(kern)
      for (i in seq_along(kern$priors)) {
        index <- kern$priors[[i]]$index
        L <- L + priorLogProb(kern$priors[[i]], params[index])
      }
    }
  }
  return (L)
}

