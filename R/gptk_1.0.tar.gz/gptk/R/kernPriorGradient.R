kernPriorGradient <-
function (kern) {
  g <- array(0, kern$nParams)

  if (kern$type %in% c('cmpnd', 'multi', 'tensor')) {
    startVal <- 1
    endVal <- 0
    for (i in seq_along(kern$comp)) {
      endVal <- endVal + kern$comp[[i]]$nParams
      g[startVal:endVal] <- kernPriorGradient(kern$comp[[i]])
      startVal <- endVal + 1
    }
    g = (g %*% kern$paramGroups)[1,]
  } else {
    if ("priors" %in% names(kern)) {
      func <- get(paste(kern$type, 'KernExtractParam', sep=''), mode='function')
      params <- func(kern)
      for (i in seq_along(kern$priors)) {
        index <- kern$priors[[i]]$index
        g[index] <- g[index] + priorGradient(kern$priors[[i]], params[index])
      }
      # Check if parameters are being optimised in a transformed space.
      if ("transforms" %in% names(kern)) {
        factors <- .kernFactors(kern, "gradfact")
        for (i in seq_along(factors))
          g[factors[[i]]$index] <- g[factors[[i]]$index]*factors[[i]]$val
      }
    }
  }

  return (g)
}

