whiteKernGradX <-
function (kern, X, X2=X) {

  gX = array(0, c(dim(as.array(X2))[1], dim(as.array(X2))[2], dim(as.array(X))[1]))

  return (gX)
}

