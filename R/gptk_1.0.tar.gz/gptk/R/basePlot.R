basePlot <-
function (K, ind) {
  ## BASEPLOT Plot the contour of the covariance.
  ## DESC creates the basic plot.

  eigVecs = eigen(K)
  U = eigVecs$vectors[ , 2:1] ## Reverse order of eigenvectors(columns).
  V = eigVecs$values
  V[V<0] = as.complex(V[V<0])
  r = Re(sqrt(V))
  theta = seq(0, 2*pi, length=200)
  xy = cbind(r[1]*sin(theta), r[2]*cos(theta))%*%U
  plot(0, type = "n", xlim=c(min(xy[,1]), max(xy[,1])),
    ylim=c(min(xy[,2]), max(xy[,2])), xlab='', ylab='') ## 'lines' only works on existing plots.
  cont = lines(xy[, 1], xy[, 2], col='blue')

  zeroAxes(xy)
}

