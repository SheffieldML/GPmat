modelTieParam <-
function (model, paramsList) {
  columnToDel <- c()

  if ( !is.list(paramsList) ) {
    paramsList <- list(paramsList)
  }

  params <- try(modelExtractParam(model, only.values=FALSE), TRUE)
  if (!is.list(params))
    params <- kernExtractParam(model, only.values=FALSE)
  
  for ( i in seq(along=paramsList) ) {
    if ( is.character(paramsList[[i]]) ) {
      paramInd <- grep(paramsList[[i]], names(params))
      if ( length(paramInd) == 0 )
        warning(paste("No matches for parameter tie spec:", paramsList[[i]]))
    }
    else {
      paramInd <- sort(paramsList[[i]])

      if ( any(paramInd[1]==columnToDel) )
        stop("Parameters have already been tied.")
    }

    if ( length(paramInd) > 1 )
      for ( j in seq(2,length.out=(length(paramInd)-1)) ) {
        model$paramGroups[paramInd[j], paramInd[1]] <- 1
        if ( any(paramInd[j]==columnToDel) )
          stop("Parameters have already been tied.")
        columnToDel <- c(columnToDel, paramInd[j])
      }
  }

  if (length(columnToDel) > 0)
    model$paramGroups <- model$paramGroups[,-columnToDel]

  if ( "nParams" %in% names(model) ) {
    model$nParams <- dim(model$paramGroups)[2]
  } else if ( "numParams" %in% names(model) ) {
    model$numParams <- dim(model$paramGroups)[2]
  }

  return (model)
}

