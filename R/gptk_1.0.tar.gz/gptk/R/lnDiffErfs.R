lnDiffErfs <-
function(x1, x2) {
  x1 <- as.matrix(x1)
  x2 <- as.matrix(x2)
  outdim <- pmax(dim(x1), dim(x2))
  outlen <- max(length(x1), length(x2))
  if (outlen > 0) {
    v <- .C("_ClnDiffErfs", as.double(x1), as.double(x2), as.integer(length(x1)), as.integer(length(x2)), v=double(outlen), s=integer(outlen))
    return (list(matrix(data=v$v, outdim), matrix(data=v$s, outdim)));
  } else {
    return (list(matrix(nrow=0, ncol=0), matrix(nrow=0, ncol=0)));
  }
}

