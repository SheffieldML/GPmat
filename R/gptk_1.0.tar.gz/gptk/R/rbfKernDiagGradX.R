rbfKernDiagGradX <-
function(kern, X) {

  gX = array(0,dim(as.array(X)))
  return (gX)
}

