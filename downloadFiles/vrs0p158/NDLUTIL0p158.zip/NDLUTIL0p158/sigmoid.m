function y = sigmoid(x)

% SIGMOID The sigmoid function
%
%	Description:
%	y = sigmoid(x)
%% 	sigmoid.m version 1.1


y = ones(size(x))./(1+exp(-x));