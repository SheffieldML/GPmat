% MOCAP toolbox
% Version 0.12		Wednesday 30 Nov 2005 at 00:56
% Copyright (c) 2005 Neil D. Lawrence
% 
% BVHCOMPUTEXYZ Compute XYZ values given structure and channels.
% BVHCONNECTIONMATRIX Compute the connection matrix for the structure.
% BVHMODIFY Helper code for visualisation of bvh data.
% BVHPLAYDATA Play bvh motion capture data.
% BVHPLAYFILE Play motion capture data from a bvh file.
% BVHREADFILE Reads a bvh file into a tree structure.
% BVHVISUALISE For updating a bvh representation of 3-D data.
% BVHWRITEFILE Write a bvh file from a given structure and channels.
% MOCAPRESULTSCPPBVH Load results from cpp file and visualise as a bvh format.
% ROTATIONMATRIX Compute the rotation matrix for an angle in each direction.
% STICKMODIFY Helper code for visualisation of a stick man.
% STICKVISUALISE For updateing a stick representation of 3-D data.
