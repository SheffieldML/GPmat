function bvhPlayFile(fileName, position)

% BVHPLAYFILE Play motion capture data from a bvh file.
%
% bvhPlayFile(fileName, position)
%

% Copyright (c) 2005 Neil D. Lawrence
% bvhPlayFile.m version 1.1



if nargin < 2
  position = 1;
end
[bvhStruct, channels, frameLength] = bvhReadFile(fileName);
bvhPlayData(bvhStruct, channels, frameLength);
