function Y = mlpOut(model, X);

% MLPOUT Output of an MLP model (wrapper for the NETLAB function mlpfwd).
%
%	Description:
%	Y = mlpOut(model, X);
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpOut.m version 1.2


Y = mlpfwd(model, X);