function modelDisplay(model, varargin)

% MODELDISPLAY Display a text output of a model.
%
%	Description:
%	modelDisplay(model, varargin)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	modelDisplay.m version 1.1


% Check if the model has display code.
if exist([model.type 'Display'])==2
  fhandle = str2func([model.type 'Display']);
  fhandle(model, varargin{:});
end
