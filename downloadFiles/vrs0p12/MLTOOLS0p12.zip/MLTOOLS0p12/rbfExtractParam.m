function params = rbfExtractParam(model)

% RBFEXTRACTPARAM Wrapper for NETLAB's rbfpak.
%
%	Description:
%	params = rbfExtractParam(model)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	rbfExtractParam.m version 1.3


params = rbfpak(model);