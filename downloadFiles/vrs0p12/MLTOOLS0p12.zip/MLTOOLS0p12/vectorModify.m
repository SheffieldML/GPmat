function handle = vectorModify(handle, values)

% VECTORMODIFY Helper code for visualisation of vectorial data.
%
%	Description:
%	handle = vectorModify(handle, values)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	vectorModify.m version 1.1


set(handle, 'YData', values);
