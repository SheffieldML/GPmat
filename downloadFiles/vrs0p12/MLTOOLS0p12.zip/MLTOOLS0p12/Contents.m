% MLTOOLS toolbox
% Version 0.12		Saturday 13 May 2006 at 15:20
% Copyright (c) 2006 Neil D. Lawrence
% 
% LVMSCATTERPLOT 2-D scatter plot of the latent points.
% MLPLOGLIKELIHOOD Multi-layer perceptron log likelihood.
% MODELEXPANDPARAM Update a model structure with parameters.
% MLPOUT Output of an MLP model (wrapper for the NETLAB function mlpfwd).
% PPCAEMBED Embed data set with probabilistic PCA.
% KBROPTIMISE Optimise a kernel based regression.
% MODELPARAMINIT Initialise the parameters of the model.
% RBFDISPLAY Display an RBF network.
% RBFOUTPUTGRAD Evaluate derivatives of rbf model outputs with respect to parameters.
% KBROUTPUTGRAD Evaluate derivatives of kernel based regression model outputs with respect to parameters.
% MODELEXTRACTPARAM Extract the parameters of a model.
% LINEAROUT Obtain the output of the linear model.
% MLPEXPANDPARAM Update mlp model with new vector of parameters.
% MLPOPTIMISE Optimise MLP for given inputs and outputs.
% ISOMAPEMBED Embed data set with Isomap.
% MLPLOGLIKEGRADIENTS Multi-layer perceptron gradients.
% LINEAROPTIONS Options for learning a linear model.
% SPECTRUMVISUALISE Helper code for showing an spectrum during 2-D visualisation.
% MODELOUTPUTGRAD Compute derivatives with respect to params of model outputs.
% MODELGRADIENT Gradient of error function to minimise for given model.
% MLPOUTPUTGRAD Evaluate derivatives of mlp model outputs with respect to parameters.
% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
% MODELDISPLAY Display a text output of a model.
% KBROUT Obtain the output of the kernel based regression model.
% RBFEXTRACTPARAM Wrapper for NETLAB's rbfpak.
% MODELOPTIMISE Optimise the given model.
% LVMCLASSVISUALISE Callback function for visualising data in 2-D.
% KBROPTIONS Kernel based regression options.
% MODELLOGLIKELIHOOD Compute a model log likelihood.
% KPCAEMBED Embed data set with kernel PCA.
% RBFEXPANDPARAM Update rbf model with new vector of parameters.
% RBFOUT Output of an RBF model (wrapper for the NETLAB function rbffwd).
% LINEAREXPANDPARAM Update linear model with vector of parameters.
% KBREXPANDPARAM Update kernel based regression model with vector of parameters.
% MODELOBJECTIVE Objective function to minimise for given model.
% MLPOPTIONS Options for the multi-layered perceptron.
% MLPPARAMINIT Initialise the parameters of an MLP model.
% RBFOPTIONS Default options for RBF network.
% VECTORMODIFY Helper code for visualisation of vectorial data.
% MLPCREATE Wrapper for NETLAB's mlp `net'.
% MAPPINGOPTIMISE Optimise the given model.
% MODELCREATE Create a model of the specified type.
% MODELLOGLIKEGRADIENTS Compute a model's gradients wrt log likelihood.
% LINEARCREATE Create a linear model.
% LVMSCATTERPLOTCOLOR 2-D scatter plot of the latent points with color - for Swiss Roll data.
% MODELOUT Give the output of a model for given X.
% MLPEXTRACTPARAM Wrapper for NETLAB's mlppak.
% LLEEMBED Embed data set with LLE.
% MODELTIEPARAM Tie parameters of a model together.
% LINEAROPTIMISE Optimise a linear model.
% SPECTRUMMODIFY Helper code for visualisation of spectrum data.
% KBRCREATE Create a kernel based regression model.
% LVMTWODPLOT Helper function for plotting the labels in 2-D.
% LINEAREXTRACTPARAM Extract weights from a linear model.
% MODELSAMP Give a sample from a model for given X.
% LINEAROUTPUTGRAD Evaluate derivatives of linear model outputs with respect to parameters.
% IMAGEVISUALISE Helper code for showing an image during 2-D visualisation.
% MODELTEST Run some tests on the specified model.
% MODELOPTIONS Returns a default options structure for the given model.
% RBFOPTIMISE Optimise RBF for given inputs and outputs.
% KBREXTRACTPARAM Extract weights from a kernel based regression model.
% RBFCREATE Wrapper for NETLAB's rbf `net'.
% MLPDISPLAY Display the multi-layer perceptron model.
