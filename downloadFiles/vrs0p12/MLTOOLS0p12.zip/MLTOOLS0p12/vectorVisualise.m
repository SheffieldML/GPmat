function handle = vectorVisualise(vals)

% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
%
%	Description:
%	handle = vectorVisualise(vals)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	vectorVisualise.m version 1.1


handle = plot(vals);
