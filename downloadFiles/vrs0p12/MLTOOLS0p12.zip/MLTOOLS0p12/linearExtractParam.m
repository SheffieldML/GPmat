function params = linearExtractParam(model);

% LINEAREXTRACTPARAM Extract weights from a linear model.
%
%	Description:
%	params = linearExtractParam(model);
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	linearExtractParam.m version 1.2


params = [model.W(:)' model.b];