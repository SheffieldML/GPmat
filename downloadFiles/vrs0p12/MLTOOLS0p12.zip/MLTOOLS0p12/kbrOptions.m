function options = kbrOptions(X)

% KBROPTIONS Kernel based regression options.
%
%	Description:
%	options = kbrOptions(X)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	kbrOptions.m version 1.1


options.kern = 'rbf';
options.X = X;
