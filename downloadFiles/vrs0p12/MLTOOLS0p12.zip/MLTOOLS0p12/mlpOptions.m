function options = mlpOptions

% MLPOPTIONS Options for the multi-layered perceptron.
%
%	Description:
%	options = mlpOptions
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpOptions.m version 1.2


options.hiddenDim = 20;
options.activeFunc = 'linear';
options.optimiser = 'conjgrad';