function model = kbrExpandParam(model, params);

% KBREXPANDPARAM Update kernel based regression model with vector of parameters.
%
%	Description:
%	model = kbrExpandParam(model, params);
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	kbrExpandParam.m version 1.3

startVal = 1;
endVal = model.numData*model.outputDim;
model.A = reshape(params(1:endVal), model.numData, model.outputDim);
model.bias = params(endVal+1:end);