function options = rbfOptions

% RBFOPTIONS Default options for RBF network.
%
%	Description:
%	options = rbfOptions
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	rbfOptions.m version 1.1


options.outFunc = 'linear';
options.activeFunc = 'gaussian';
options.hiddenDim = 20;
