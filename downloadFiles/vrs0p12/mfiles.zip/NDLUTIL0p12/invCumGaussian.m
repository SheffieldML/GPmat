function y = invCumGaussian(x)

% INVCUMGAUSSIAN Inverser of the cumulative Gaussian.
%
% y = invCumGaussian(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Thu Jun 17 15:07:56 2004
% NDLUTIL toolbox version 0.12



y = erfinv(x*2 - 1)*2/sqrt(2);