% NDLUTIL toolbox
% Version 0.12 Monday, July 12, 2004 at 19:13:23
% Copyright (c) 2004 Neil D. Lawrence
% 
% CUMGAUSSIAN Cumulative distribution for Gaussian.
% GAUSSOVERDIFFCUMGAUSSIAN A gaussian in x over the difference between two cumulative Gaussians. 
% GAUSSSAMP Sample from a Gaussian with a given covariance.
% GETSYMBOLS Get a cell structure of different plot symbols.
% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
% INVCUMGAUSSIAN Inverser of the cumulative Gaussian.
% INVSIGMOID The inverse of the sigmoid function.
% LNCUMGAUSSIAN log cumulative distribution for Gaussian.
% LNDIFFCUMGAUSSIAN Computes the log of the difference between two cumulative Gaussians.
% LOGDET The log of the determinant when argument is positive definite.
% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
% PDINV Computes the inverse of a positive definite matrix
% PREPAREPLOT Helper function for tidying up the plot before printing.
% ROCCURVE Draw ROC curve and return labels.
% SIGMOID The sigmoid function
% ZEROAXES A function to move the axes crossing point to the origin.
