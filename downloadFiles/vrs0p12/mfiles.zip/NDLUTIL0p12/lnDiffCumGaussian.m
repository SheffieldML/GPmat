function f = lnDiffCumGaussian(u, uprime)

% LNDIFFCUMGAUSSIAN Computes the log of the difference between two cumulative Gaussians.
%
% f = lnDiffCumGaussian(u, uprime)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Mon Jul 12 17:09:12 2004
% NDLUTIL toolbox version 0.12



% f = log(\phi(u) - phi(uprime))


f = log(gaussOverDiffCumGaussian(u, uprime, 1)+1e-300) + .5*u.*u + .5*log(2*pi);