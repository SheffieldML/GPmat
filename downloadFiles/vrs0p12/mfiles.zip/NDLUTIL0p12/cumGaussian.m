function y = cumGaussian(x)

% CUMGAUSSIAN Cumulative distribution for Gaussian.
%
% y = cumGaussian(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:30:10 2004
% NDLUTIL toolbox version 0.12






y = 0.5*(1+erf(sqrt(2)/2*x));
