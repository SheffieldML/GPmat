% OPTIMI toolbox
% Version 0.12 Monday, July 12, 2004 at 19:25:18
% Copyright (c) 2004 Neil D. Lawrence
% 
% CMPNDTIEPARAMETERS Tie parameters together.
% EXPTRANSFORM Constrains a parameter to be positive through exponentiation.
% NEGLOGLOGIT Constrains a parameter to be positive.
% OPTIMISEPARAMS Optimise parameters.
% SIGMOIDTRANSFORM Constrains a parameter to be between 0 and 1.
