function y = sigmoid(x)

% SIGMOID The sigmoid function
%
%	Description:
%	y = sigmoid(x)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	sigmoid.m version 1.1


y = ones(size(x))./(1+exp(-x));