% NDLUTIL toolbox
% Version 0.154		Friday 05 Jan 2007 at 22:39
% Copyright (c) 2007 Neil D. Lawrence
% 
% JITCHOL Do a Cholesky decomposition with jitter.
% LNCUMGAUSSIAN log cumulative distribution for the normalised Gaussian.
% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
% XLOGY z = x*log(y) returns zero if x=y=0
% TRACEPRODUCT Returns the trace of the product of two matrices.
% KLDIVGAUSSIAN Give the KL divergence between two Gaussians.
% DEG2RAD Transform degrees to radians.
% GRADIENTCHECK Check gradients of objective function.
% SCATTERPLOT 2-D scatter plot of labelled points.
% GAUSSSAMP Sample from a Gaussian with a given covariance.
% DEFAULTOPTIONS The default options for optimisation.
% GAUSSOVERDIFFCUMGAUSSIAN A Gaussian over difference of cumulative Gaussians.
% HESSIANCHECK Check Hessian of objective function.
% INVSIGMOID The inverse of the sigmoid function.
% GETSYMBOLS Get a cell array of different plot symbols.
% LNDIFFCUMGAUSSIAN Log of the difference between two cumulative Gaussians.
% STACK Return column stacked vector of given matrix.
% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
% TABLEREAD Read in data which has column titles in the first line and separated values in each other line.
% GETLINE Get a line from a file.
% NUMSF2STR Convert number to a string with a number of significant digits.
% INVCUMGAUSSIAN Computes inverse of the cumulative Gaussian.
% CUMGAUSSIAN Cumulative distribution for Gaussian.
% PREPAREPLOT Helper function for tidying up the plot before printing.
% NEGLOGLOGIT Function which returns the negative log of the logistic function.
% ROCCURVE Draw ROC curve and return labels.
% LOGDET The log of the determinant when argument is positive definite.
% STRINGSPLIT Return separate parts of a string.
% PDINV Invert a positive definite matrix.
% ZEROAXES A function to move the axes crossing point to the origin.
% TOKENISE Split a string into separate tokens.
% SIGMOID The sigmoid function
% STRINGSIGFIGS Convert number to a string with a number of significant digits.
% SPARSEDIAG Create a diagonal matrix that is sparse from a vector.
