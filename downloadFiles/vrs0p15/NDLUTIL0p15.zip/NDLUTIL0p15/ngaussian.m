function y = ngaussian(x)

% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
%
% y = ngaussian(x)
%

% Copyright (c) 2006 Neil D. Lawrence
% ngaussian.m version 1.1



x2 = x.*x;
y = exp(-.5*x2);
y = y/sqrt(2*pi);
