% MLTOOLS toolbox
% Version 0.1291		05-Oct-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% MODELLOGLIKEGRADIENTS Compute a model's gradients wrt log likelihood.
% MOGTWODPLOT Helper function for plotting the labels in 2-D.
% MLPOUTPUTGRAD Evaluate derivatives of mlp model outputs with respect to parameters.
% RBFOUT Output of an RBF model.
% DNETLOGLIKEGRADIENTS Density network gradients.
% DEMSWISSROLLLLE4 Demonstrate LLE on the oil data.
% MOGESTEP Do an E-step on an MOG model.
% DEMMPPCA1 Demonstrate MPPCA on a artificial dataset.
% PPCAEMBED Embed data set with probabilistic PCA.
% LINEARLOGLIKELIHOOD Linear model log likelihood.
% DEMSWISSROLLFULLLLE4 Demonstrate LLE on the oil data.
% IMAGEMODIFY Helper code for visualisation of image data.
% RBFCREATE Wrapper for NETLAB's rbf `net'.
% RBFEXTRACTPARAM Wrapper for NETLAB's rbfpak.
% DEMSWISSROLLLLE2 Demonstrate LLE on the oil data.
% MLPDISPLAY Display the multi-layer perceptron model.
% LVMVISUALISE Visualise the manifold.
% LLEOPTIMISE Optimise an LLE model.
% RBFOPTIONS Default options for RBF network.
% MOGLOWERBOUND Computes lower bound on log likelihood for an MOG model.
% MOGSAMPLE Sample from a mixture of Gaussians model.
% DNETOUT Output of an DNET model.
% MODELOUTPUTGRADX Compute derivatives with respect to model inputs of model outputs.
% MLPLOGLIKEHESSIAN Multi-layer perceptron Hessian.
% LINEAROUTPUTGRAD Evaluate derivatives of linear model outputs with respect to parameters.
% KBRPARAMINIT KBR model parameter initialisation.
% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
% DOUBLEMATRIXREADFROMFID Read a full matrix from an FID.
% MODELOUT Give the output of a model for given X.
% KPCAEMBED Embed data set with kernel PCA.
% MULTIMODELLOGLIKEGRADIENTS Gradient of MULTIMODEL model log likelihood with respect to parameters.
% MLPOUTPUTGRADX Evaluate derivatives of mlp model outputs with respect to inputs.
% DEMSWISSROLLFULLLLE3 Demonstrate LLE on the oil data.
% MODELOBJECTIVE Objective function to minimise for given model.
% DNETGRADIENT Density Network gradient wrapper.
% DNETPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% KBRCREATE Create a KBR model.
% RBFPERIODICOPTIONS Create a default options structure for the RBFPERIODIC model.
% MOGOPTIMISE Optimise an MOG model.
% DNETUPDATEBETA Do an M-step (update parameters) on an Density Network model.
% MOGCREATE Create a mixtures of Gaussians model.
% IMAGEVISUALISE Helper code for showing an image during 2-D visualisation.
% MLPLOGLIKEGRADIENTS Multi-layer perceptron gradients.
% LINEAROUT Obtain the output of the linear model.
% LVMCLASSVISUALISE Callback function for visualising data in 2-D.
% DNETOUTPUTGRAD Evaluate derivatives of dnet model outputs with respect to parameters.
% RBFDISPLAY Display an RBF network.
% LVMTWODPLOT Helper function for plotting the labels in 2-D.
% MLPEXTRACTPARAM Extract weights and biases from an MLP.
% MULTIMODELLOGLIKELIHOOD Log likelihood of MULTIMODEL model.
% MOGMEANCOV Project a mixture of Gaussians to a low dimensional space.
% DEMSWISSROLLLLE3 Demonstrate LLE on the oil data.
% PPCAOPTIONS Options for probabilistic PCA.
% MODELEXPANDPARAM Update a model structure with parameters.
% MODELREADFROMFID Load from a FID produced by C++ code.
% LVMSCATTERPLOT 2-D scatter plot of the latent points.
% SPRINGDAMPERSVISUALISE Helper code for showing an spring dampers during 2-D visualisation.
% KBREXTRACTPARAM Extract parameters from the KBR model structure.
% RBFOUTPUTGRADX Evaluate derivatives of a RBF model's output with respect to inputs.
% RBFPERIODICPARAMINIT RBFPERIODIC model parameter initialisation.
% RBFPERIODICCREATE Create a RBFPERIODIC model.
% MOGPRINTPLOT Print projection of MOG into two dimensions.
% MVUEMBED Embed data set with MVU.
% RBFPERIODICLOGLIKELIHOOD Log likelihood of RBFPERIODIC model.
% MULTIMODELDISPLAY Display parameters of the MULTIMODEL model.
% RBFEXPANDPARAM Update rbf model with new vector of parameters.
% MODELPARAMINIT Initialise the parameters of the model.
% KBRDISPLAY Display parameters of the KBR model.
% PPCACREATE Density network model.
% LINEARLOGLIKEGRADIENTS Linear model gradients.
% LLECREATE Locally linear embedding model.
% DNETESTEP Do an E-step (update importance weights) on an Density Network model.
% RBFPERIODICEXPANDPARAM Create model structure from RBFPERIODIC model's parameters.
% MOGUPDATEMEAN Update the means of an MOG model.
% MODELTIEPARAM Tie parameters of a model together.
% DEMSWISSROLLLLE1 Demonstrate LLE on the oil data.
% RBFPERIODICDISPLAY Display parameters of the RBFPERIODIC model.
% MLPOPTIMISE Optimise MLP for given inputs and outputs.
% LVMPRINTPLOT Print latent space for learnt model.
% MODELDISPLAY Display a text output of a model.
% SPRINGDAMPERSMODIFY Helper code for visualisation of springDamper data.
% LINEAREXPANDPARAM Update linear model with vector of parameters.
% MODELLOGLIKELIHOOD Compute a model log likelihood.
% LVMSCATTERPLOTCOLOR 2-D scatter plot of the latent points with color.
% DNETUPDATEOUTPUTWEIGHTS Do an M-step (update parameters) on an Density Network model.
% DOUBLEMATRIXWRITETOFID Writes a double matrix to an FID.
% RBFPERIODICEXTRACTPARAM Extract parameters from the RBFPERIODIC model structure.
% MLPLOGLIKELIHOOD Multi-layer perceptron log likelihood.
% MOGOPTIONS Sets the default options structure for MOG models.
% FINDNEIGHBOURS find the k nearest neighbours for each point in Y.
% MODELHESSIAN Hessian of error function to minimise for given model.
% SMALLRANDEMBED Embed data set with small random values.
% RBFPERIODICOUTPUTGRAD Evaluate derivatives of RBFPERIODIC model outputs with respect to parameters.
% KBROUT Compute the output of a KBR model given the structure and input X.
% DEMOILLLE2 Demonstrate LLE on the oil data.
% MAPMODELREADFROMFID Load from a FID produced by C++ code.
% LVMCLASSVISUALISEPATH Latent variable model path drawing in latent space.
% LVMSCATTERPLOTNEIGHBOURS 2-D scatter plot of the latent points with neighbourhood.
% MODELEXTRACTPARAM Extract the parameters of a model.
% KBROPTIONS Create a default options structure for the KBR model.
% MOGLOGLIKELIHOOD Mixture of Gaussian's log likelihood.
% DEMOILLLE1 Demonstrate LLE on the oil data.
% MODELPOINTLOGLIKELIHOOD Compute the log likelihood of a given point.
% DNETLOGLIKELIHOOD Density network log likelihood.
% KBROUTPUTGRAD Evaluate derivatives of KBR model outputs with respect to parameters.
% MODELGRADIENTCHECK Check gradients of given model.
% MODELGRADIENT Gradient of error function to minimise for given model.
% MODELOPTIMISE Optimise the given model.
% MODELCREATE Create a model of the specified type.
% VECTORMODIFY Helper code for visualisation of vectorial data.
% MAPPINGOPTIMISE Optimise the given model.
% KBROPTIMISE Optimise a KBR model.
% DNETEXTRACTPARAM Extract weights and biases from an DNET.
% DNETLOWERBOUND Computes lower bound on log likelihood for an DNET model.
% RBFPERIODICLOGLIKEGRADIENTS Gradient of RBFPERIODIC model log likelihood with respect to parameters.
% MOGPROJECT Project a mixture of Gaussians to a low dimensional space.
% MOGUPDATEPRIOR Update the priors of an MOG model.
% MODELADDDYNAMICS Add a dynamics kernel to the model.
% MLPOUT Output of an MLP model.
% LVMLOADRESULT Load a previously saved result.
% DNETOPTIMISE Optimise an DNET model.
% MLPPARAMINIT Initialise the parameters of an MLP model.
% LINEAROPTIMISE Optimise a linear model.
% MOGUPDATECOVARIANCE Update the covariances of an MOG model.
% MULTIMODELEXPANDPARAM Create model structure from MULTIMODEL model's parameters.
% LINEAREXTRACTPARAM Extract weights from a linear model.
% LINEARCREATE Create a linear model.
% VITERBIALIGN Compute the Viterbi alignment.
% MULTIMODELCREATE Create a MULTIMODEL model.
% DNETEXPANDPARAM Update dnet model with new vector of parameters.
% MODELSETOUTPUTWEIGHTS Wrapper function to return set output weight and bias matrices.
% MODELOUTPUTGRAD Compute derivatives with respect to params of model outputs.
% DNETOUTPUTGRADX Evaluate derivatives of DNET model outputs with respect to inputs.
% SPECTRUMMODIFY Helper code for visualisation of spectrum data.
% LLEOPTIONS Options for a density network.
% DEMSWISSROLLFULLLLE2 Demonstrate LLE on the oil data.
% MODELSAMP Give a sample from a model for given X.
% PPCAPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% MODELREADFROMFILE Read model from a file FID produced by the C++ implementation.
% KBREXPANDPARAM Create model structure from KBR model's parameters.
% DNETOBJECTIVE Wrapper function for Density Network objective.
% RBFPERIODICOUT Compute the output of a RBFPERIODIC model given the structure and input X.
% MLTOOLSTOOLBOXES Load in the relevant toolboxes for the MLTOOLS.
% LVMRESULTSDYNAMIC Load a results file and visualise them.
% DEMSWISSROLLFULLLLE1 Demonstrate LLE on the oil data.
% MLPCREATE Multi-layer peceptron model.
% RBFPERIODICOUTPUTGRADX Evaluate derivatives of a RBFPERIODIC model's output with respect to inputs.
% LINEAROUTPUTGRADX Evaluate derivatives of linear model outputs with respect to inputs.
% ISOMAPEMBED Embed data set with Isomap.
% MODELWRITETOFID Write to a stream a given model.
% LINEARPARAMINIT Initialise the parameters of an LINEAR model.
% SPECTRUMVISUALISE Helper code for showing an spectrum during 2-D visualisation.
% MATRIXREADFROMFID Read a matrix from an FID.
% DNETTEST Test some settings for the density network.
% MULTIMODELPARAMINIT MULTIMODEL model parameter initialisation.
% MULTIMODELEXTRACTPARAM Extract parameters from the MULTIMODEL model structure.
% MODELOPTIONS Returns a default options structure for the given model.
% MLPEXPANDPARAM Update mlp model with new vector of parameters.
% DEMOILLLE3 Demonstrate LLE on the oil data.
% LVMNEARESTNEIGHBOUR Give the number of errors in latent space for 1 nearest neighbour.
% MODELTEST Run some tests on the specified model.
% LINEAROPTIONS Options for learning a linear model.
% DEMOILLLE4 Demonstrate LLE on the oil data.
% DNETOPTIONS Options for a density network.
% LLEEMBED Embed data set with LLE.
% RBFOUTPUTGRAD Evaluate derivatives of rbf model outputs with respect to parameters.
% MODELGETOUTPUTWEIGHTS Wrapper function to return output weight and bias matrices.
% MULTIMODELOPTIONS Create a default options structure for the MULTIMODEL model.
% LMVUEMBED Embed data set with landmark MVU
% DNETCREATE Density network model.
% MLPOPTIONS Options for the multi-layered perceptron.
% PPCAOUT Output of an PPCA model.
% LINEARDISPLAY Display a linear model.
% RBFOPTIMISE Optimise RBF for given inputs and outputs.
