function Y = linearOut(model, X);

% LINEAROUT Obtain the output of the linear model.
%
%	Description:
%	Y = linearOut(model, X);
%% 	linearOut.m CVS version 1.2
% 	linearOut.m SVN version 24
% 	last update 2005-12-18T12:26:23.000000Z

numData = size(X, 1);
Y = X*model.W + ones(numData, 1)*model.b;
