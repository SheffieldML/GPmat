function model = mlpCreate(inputDim, outputDim, options)

% MLPCREATE Wrapper for NETLAB's mlp `net'.
%
%	Description:
%
%	MODEL = MLPCREATE(INPUTDIMENSION, OUTPUTDIM, OPTIONS) creates a
%	structure used as a wrapper structure for NETLAB's multi-layer
%	perceptron model.
%	 Returns:
%	  MODEL - model structure containing the neural networks specified.
%	 Arguments:
%	  INPUTDIMENSION - dimension of input data.
%	  OUTPUTDIM - dimension of target data.
%	  OPTIONS - options structure. The structure contains the type of
%	   output 'activation function', the number of hidden units and the
%	   optimiser to be used. A set of default options are given by the
%	   file mlpOptions.
%	
%
%	See also
%	MLPOPTIONS, MLP


%	Copyright (c) 2005, 2006 Neil D. Lawrence
% 	mlpCreate.m version 1.3



model = mlp(inputDim, options.hiddenDim, outputDim, options.activeFunc);
model.optimiser = options.optimiser;
model.numParams = model.nwts;
model.inputDim = inputDim;
model.outputDim = outputDim;
