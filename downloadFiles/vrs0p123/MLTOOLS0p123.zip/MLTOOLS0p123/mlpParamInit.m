function model = mlpParamInit(model)

% MLPPARAMINIT Initialise the parameters of an MLP model.
%
%	Description:
%
%	MODEL = MLPPARAMINIT(MODEL) sets the initial weight vectors and
%	biases to small random values.
%	 Returns:
%	  MODEL - the initialised model.
%	 Arguments:
%	  MODEL - the input model to initialise.
%	
%
%	See also
%	MODELPARAMINIT, MLPCREATE


%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpParamInit.m version 1.1


model.w1 = randn(model.inputDim, model.nhidden)/sqrt(model.inputDim + 1);
model.b1 = randn(1, model.nhidden)/sqrt(model.inputDim + 1);
model.w2 = randn(model.nhidden, model.outputDim)/sqrt(model.nhidden + 1);
model.b2 = randn(1, model.outputDim)/sqrt(model.nhidden + 1);
