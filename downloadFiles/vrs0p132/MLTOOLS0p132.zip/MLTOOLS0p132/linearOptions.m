function options = linearOptions;

% LINEAROPTIONS Options for learning a linear model.
%
%	Description:
%	options = linearOptions;
%% 	linearOptions.m CVS version 1.1
% 	linearOptions.m SVN version 24
% 	last update 2007-11-03T14:24:25.000000Z

options.activeFunc = 'linear';