function model = spectralUpdateLaplacian(model)

% SPECTRALUPDATELAPLACIAN Update the Laplacian using graph connections.
%
%	Description:
%
%	MODEL = SPECTRALUPDATELAPLACIAN(MODEL) updates the Laplacian matrix
%	using values of the internode connections.
%	 Returns:
%	  MODEL - the updated model.
%	 Arguments:
%	  MODEL - the model to be updated.
%	
%
%	See also
%	SPECTRALUPDATEX, LEOPTIMISE


%	Copyright (c) 2009 Neil D. Lawrence
% 	spectralUpdateLaplacian.m SVN version 503
% 	last update 2009-09-01T18:19:22.000000Z

for i = 1:size(model.indices, 1)
  for j = 1:model.k
    model.L(i, model.indices(i, j)) = -model.kappa(i, j);
    model.L(model.indices(i, j), i) = model.L(i, model.indices(i, j));
  end
end
% Set diagonal
D = sum(model.kappa, 2);
model.L(1:model.N+1:end) = D;
if model.isNormalised
  sqrtD = sqrt(D);
  model.L = (model.L.*(sqrtD*sqrtD'));
end
