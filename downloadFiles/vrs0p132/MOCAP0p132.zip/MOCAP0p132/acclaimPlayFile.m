function acclaimPlayFile(fileNameAsf, fileNameAmc, frameLength)

% ACCLAIMPLAYFILE Play motion capture data from a asf and amc file.
%
%	Description:
%	acclaimPlayFile(fileNameAsf, fileNameAmc, frameLength)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	acclaimPlayFile.m version 1.1


skel = acclaimReadSkel(fileNameAsf);
[channels, skel] = acclaimLoadChannels(fileNameAmc, skel);
skelPlayData(skel, channels, frameLength);
