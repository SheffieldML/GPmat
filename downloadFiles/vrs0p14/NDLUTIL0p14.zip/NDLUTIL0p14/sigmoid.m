function y = sigmoid(x)

% SIGMOID The sigmoid function
%
% y = sigmoid(x)
%

% Copyright (c) 2005 Neil D. Lawrence
% sigmoid.m version 1.1



y = ones(size(x))./(1+exp(-x));