function y = invCumGaussian(x)

% INVCUMGAUSSIAN Inverser of the cumulative Gaussian.
%
% y = invCumGaussian(x)
%

% Copyright (c) 2005 Neil D. Lawrence
% invCumGaussian.m version 1.1



y = erfinv(x*2 - 1)*2/sqrt(2);