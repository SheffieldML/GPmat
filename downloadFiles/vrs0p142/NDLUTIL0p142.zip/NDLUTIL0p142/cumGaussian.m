function y = cumGaussian(x)

% CUMGAUSSIAN Cumulative distribution for Gaussian.
%
% y = cumGaussian(x)
%

% Copyright (c) 2005 Neil D. Lawrence
% cumGaussian.m version 1.1



y = 0.5*(1+erf(sqrt(2)/2*x));
