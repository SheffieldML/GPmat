function y=invSigmoid(x)

% INVSIGMOID The inverse of the sigmoid function.
%
% y=invSigmoid(x)
%

% Copyright (c) 2005 Neil D. Lawrence
% invSigmoid.m version 1.1



y = log(x./(1-x));