% NDLUTIL toolbox
% Version 0.142		Tuesday 27 Dec 2005 at 18:16
% Copyright (c) 2005 Neil D. Lawrence
% 
% CUMGAUSSIAN Cumulative distribution for Gaussian.
% DEFAULTOPTIONS The default options for optimisation.
% GAUSSOVERDIFFCUMGAUSSIAN A gaussian in x over the difference between two cumulative Gaussians. 
% GAUSSSAMP Sample from a Gaussian with a given covariance.
% GETLINE Get a line from a file, but ignore it if it starts with #.
% GETSYMBOLS Get a cell structure of different plot symbols.
% GRADIENTCHECK Check gradients of objective function.
% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
% INVCUMGAUSSIAN Inverser of the cumulative Gaussian.
% INVSIGMOID The inverse of the sigmoid function.
% LNCUMGAUSSIAN log cumulative distribution for Gaussian.
% LNDIFFCUMGAUSSIAN Computes the log of the difference between two cumulative Gaussians.
% LOGDET The log of the determinant when argument is positive definite.
% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
% NUMSF2STR Convert number to a string with a number of significant digits.
% PDINV Computes the inverse of a positive definite matrix
% PREPAREPLOT Helper function for tidying up the plot before printing.
% ROCCURVE Draw ROC curve and return labels.
% SCATTERPLOT 2-D scatter plot of labelled points.
% SIGMOID The sigmoid function
% SPARSEDIAG Create a diagonal matrix that is sparse from a vector.
% STACK Return column stacked vector of given matrix.
% NUM2STRSIGFIG Convert number to a string with a number of significant digits.
% STRINGSPLIT Return separate parts of a string.
% TABLEREAD Read in data which has column titles in the first line and separated values in each other line.
% TOKENISE Split a string into separate tokens.
% TRACEPRODUCT Returns the trace of the product of two matrices.
% ZEROAXES A function to move the axes crossing point to the origin.
