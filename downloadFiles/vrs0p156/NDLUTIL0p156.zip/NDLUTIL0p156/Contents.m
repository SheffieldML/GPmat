% NDLUTIL toolbox
% Version 0.156		03-Feb-2007
% Copyright (c) 2007 Neil D. Lawrence
% 
% CUMGAUSSIAN Cumulative distribution for Gaussian.
% DEFAULTOPTIONS The default options for optimisation.
% DEG2RAD Transform degrees to radians.
% GAUSSOVERDIFFCUMGAUSSIAN A Gaussian over difference of cumulative Gaussians.
% GAUSSSAMP Sample from a Gaussian with a given covariance.
% GETLINE Get a line from a file.
% GETSYMBOLS Get a cell array of different plot symbols.
% GRADIENTCHECK Check gradients of objective function.
% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
% HESSIANCHECK Check Hessian of objective function.
% INVCUMGAUSSIAN Computes inverse of the cumulative Gaussian.
% INVSIGMOID The inverse of the sigmoid function.
% JITCHOL Do a Cholesky decomposition with jitter.
% KLDIVGAUSSIAN Give the KL divergence between two Gaussians.
% LNCUMGAUSSIAN log cumulative distribution for the normalised Gaussian.
% LNCUMGAUSSSUM The log of the weighted sum of two cumulative Gaussians.
% LNDIFFCUMGAUSSIAN Log of the difference between two cumulative Gaussians.
% LOGDET The log of the determinant when argument is positive definite.
% NDLUTILTOOLBOXES Loads in toolboxes for NDLUTIL.
% NEGLOGLOGIT Function which returns the negative log of the logistic function.
% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
% NUMSF2STR Convert number to a string with a number of significant digits.
% PDINV Invert a positive definite matrix.
% PREPAREPLOT Helper function for tidying up the plot before printing.
% ROCCURVE Draw ROC curve and return labels.
% SCATTERPLOT 2-D scatter plot of labelled points.
% SIGMOID The sigmoid function
% SPARSEDIAG Create a diagonal matrix that is sparse from a vector.
% STACK Return column stacked vector of given matrix.
% STRINGSIGFIGS Convert number to a string with a number of significant digits.
% STRINGSPLIT Return separate parts of a string.
% TABLEREAD Read in data which has column titles in the first line and separated values in each other line.
% TOKENISE Split a string into separate tokens.
% TRACEPRODUCT Returns the trace of the product of two matrices.
% TREEFINDCHILDREN Given a tree that lists only parents, add children.
% TREEFINDPARENTS Given a tree that lists only children, add parents.
% TREEFINDROOTS Return indices of all root nodes in a tree structure.
% TREEGETWIDTHS give width of each level of tree.
% TREESWAPNODE Swap two nodes in the tree structure array.
% XLOGY z = x*log(y) returns zero if x=y=0
% ZEROAXES A function to move the axes crossing point to the origin.
