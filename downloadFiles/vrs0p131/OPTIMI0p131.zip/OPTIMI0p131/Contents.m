% OPTIMI toolbox
% Version 0.131		Saturday 14 Oct 2006 at 23:01
% Copyright (c) 2006 Neil D. Lawrence
% 
% CGCARL Wrapper for Carl Rasmussen's conjugate gradient implemntation.
% CMPNDTIEPARAMETERS Tie parameters together.
% EXPTRANSFORM Constrains a parameter to be positive through exponentiation.
% GRADFUNCWRAPPER Wrapper function to enable use of Carl Rasmussen's minimze function.
% NEGLOGLOGITTRANSFORM Constrains a parameter to be positive.
% OPTIMISEPARAMS Optimise parameters.
% OPTOPTIONS Give optimisation options for NETLAB.
% SIGMOIDTRANSFORM Constrains a parameter to be between 0 and 1.
