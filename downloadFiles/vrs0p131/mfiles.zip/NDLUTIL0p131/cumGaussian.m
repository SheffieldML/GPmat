function y = cumGaussian(x)

% CUMGAUSSIAN Cumulative distribution for Gaussian.
%
% y = cumGaussian(x)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Sun Jan  2 15:54:38 2005
% NDLUTIL toolbox version 0.131



y = 0.5*(1+erf(sqrt(2)/2*x));
