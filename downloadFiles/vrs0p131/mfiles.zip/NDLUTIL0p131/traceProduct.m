function t = traceProduct(A, B)

% TRACEPRODUCT Returns the trace of the product of two matrices.
%
% t = traceProduct(A, B)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Dec 11 17:20:52 2004
% NDLUTIL toolbox version 0.131



t = sum(sum(A.*B'));