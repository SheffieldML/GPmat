function options = defaultOptions;

% DEFAULTOPTIONS The default options for optimisation.
%
% options = defaultOptions;

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Tue Jan 25 17:09:03 2005
% NDLUTIL toolbox version 0.131



options = [0,  1e-4, 1e-4, 1e-6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1e-8, 0.1, 0];