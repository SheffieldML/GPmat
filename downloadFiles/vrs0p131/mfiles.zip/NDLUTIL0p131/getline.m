function lineStr = getline(FID)

% GETLINE Get a line from a file, but ignore it if it starts with #.
%
% lineStr = getline(FID)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Wed Jul 27 16:11:19 2005
% NDLUTIL toolbox version 0.131



lineStr = fgetl(FID);
if length(lineStr)==0
  return
end
while lineStr(1)=='#' 
  lineStr = fgetl(FID);
end