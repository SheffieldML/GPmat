function y = lnCumGaussian(x)

% LNCUMGAUSSIAN log cumulative distribution for Gaussian.
%
% y = lnCumGaussian(x)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Thu Jun 17 15:07:14 2004
% NDLUTIL toolbox version 0.131



index = find(x< 0);
if length(index)
  y(index) = -.5*x(index).*x(index) + log(.5) + log(erfcx(-sqrt(2)/2* ...
                                                    x(index)));
end
index = find(x>=0);
if length(index)
  y(index) = log(cumGaussian(x(index)));
end
y=reshape(y, size(x));