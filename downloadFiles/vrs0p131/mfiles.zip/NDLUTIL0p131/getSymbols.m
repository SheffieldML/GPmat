function symbol = getSymbols(number)

% GETSYMBOLS Get a cell structure of different plot symbols.
%
% symbol = getSymbols(number)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Fri Jun 18 19:57:08 2004
% NDLUTIL toolbox version 0.131



symbolColour = {'r', 'g', 'b', 'c', 'm', 'y'};
symbolShape = {'x', 'o', '+', '*', 's', 'd', 'v', '^', '<', '>', 'p'};
counter = 0;
while counter < number
  symbol{counter+1} = [symbolColour{rem(counter, length(symbolColour))+1} ...
                      symbolShape{rem(counter, length(symbolShape))+1}];
  counter = counter +1;
end