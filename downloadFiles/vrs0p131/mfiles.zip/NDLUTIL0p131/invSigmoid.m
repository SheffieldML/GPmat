function y=invSigmoid(x)

% INVSIGMOID The inverse of the sigmoid function.
%
% y=invSigmoid(x)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Thu Jun 17 15:07:46 2004
% NDLUTIL toolbox version 0.131



y = log(x./(1-x));