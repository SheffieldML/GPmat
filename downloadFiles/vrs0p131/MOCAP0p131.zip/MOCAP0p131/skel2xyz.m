function xyz = skel2xyz(skel, channels)

% SKEL2XYZ Compute XYZ values given skeleton structure and channels.
%
% xyz = skel2xyz(skel, channels)
%

% Copyright (c) 2006 Neil D. Lawrence
% skel2xyz.m version 1.1



fname = str2func([skel.type '2xyz']);
xyz = fname(skel, channels);