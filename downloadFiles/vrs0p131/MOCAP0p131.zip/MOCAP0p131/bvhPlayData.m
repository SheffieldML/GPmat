function bvhPlayData(skel, channels, frameLength)

% BVHPLAYDATA Play bvh motion capture data.
%
% bvhPlayData(skel, channels, frameLength)
%

% Copyright (c) 2006 Neil D. Lawrence
% bvhPlayData.m version 1.1



skelPlayData(skel, channels, frameLength);