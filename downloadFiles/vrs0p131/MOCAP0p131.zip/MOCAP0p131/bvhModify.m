function bvhModify(handle, channels, skel, padding)

% BVHMODIFY Helper code for visualisation of bvh data.
%
% bvhModify(handle, channels, skel, padding)
%

% Copyright (c) 2006 Neil D. Lawrence
% bvhModify.m version 1.2




if nargin<4
  padding = 0;
end

skelModify(handle, channels, skel, padding);