function connection = bvhConnectionMatrix(skel);

% BVHCONNECTIONMATRIX Compute the connection matrix for the structure.
%
% connection = bvhConnectionMatrix(skel);
%

% Copyright (c) 2006 Neil D. Lawrence
% bvhConnectionMatrix.m version 1.2



connection = skelConnectionMatrix(skel);

