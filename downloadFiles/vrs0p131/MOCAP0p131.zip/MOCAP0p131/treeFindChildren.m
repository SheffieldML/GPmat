function tree = treeFindChildren(tree)

% TREEFINDCHILDREN Given a tree that lists only parents, add children.
%
% tree = treeFindChildren(tree)
%

% Copyright (c) 2006 Neil D. Lawrence
% treeFindChildren.m version 1.1



for i = 1:length(tree)
  for j = 1:length(tree(i).parent)
    if tree(i).parent(j)
      tree(tree(i).parent(j)).children ...
          = [tree(tree(i).parent(j)).children i];
    end
  end
end

