function y = gradLogCumGaussian(x)

% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
%
% y = gradLogCumGaussian(x)
%

% Copyright (c) 2005 Neil D. Lawrence
% gradLogCumGaussian.m version 1.1



% Theoretically this is simply ngaussian(x)/cumGaussian(x) but there are
% problems in the tails of the distribution.

y = zeros(size(x));
index = find(x>0);
y(index) = ngaussian(x(index))./cumGaussian(x(index));
index = find(x<=0);
y(index) = 1./(sqrt(2*pi)*0.5*erfcx(-sqrt(2)/2*x(index)));
