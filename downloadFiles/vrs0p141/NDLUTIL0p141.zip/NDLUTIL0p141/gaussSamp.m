function y = gaussSamp(Sigma, numSamps)

% GAUSSSAMP Sample from a Gaussian with a given covariance.
%
% y = gaussSamp(Sigma, numSamps)
%

% Copyright (c) 2005 Neil D. Lawrence
% gaussSamp.m version 1.1



[U, V] = eig(Sigma);
dims = size(Sigma, 1);
y = randn(numSamps, dims);
y = y*diag(sqrt(diag(V)));
y = y*U';