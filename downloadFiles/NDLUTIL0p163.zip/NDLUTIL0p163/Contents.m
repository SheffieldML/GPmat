% NDLUTIL toolbox
% Version 0.163		17-Jun-2012
% Copyright (c) 2012, Neil D. Lawrence
% 
, Neil D. Lawrence
% READDOUBLEFROMFID Read a double from an FID.
% READBINARYDOUBLES Read information from a binary file in as doubles.
% CUMGAUSSIAN Cumulative distribution for Gaussian.
% PLOTMATRIXOPTIONS Default options for plot matrix.
% TRACEPRODUCT Returns the trace of the product of two matrices.
% STRINGSPLIT Return separate parts of a string.
% LNDIFFERFS Helper function for computing the log of difference
% TREEGETWIDTHS give width of each level of tree.
% PRINTPLOT Print a plot to eps and png files.
% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
% XGAMRND Draw a sample from the gamma distribution.
% LNCUMGAUSSSUM The log of the weighted sum of two cumulative Gaussians.
% WRITEINTTOFID Writes an integer to an FID.
% PRINTLATEXOPTIONS Options for printing a plot to LaTeX.
% TREEFINDLEAVES Return indices of all leaf nodes in a tree structure.
% DEFAULTOPTIONS The default options for optimisation.
% HESSIANCHECK Check Hessian of objective function.
% WRITESTRINGTOFID Writes a string to an FID.
% GRADLNDIFFERFS Compute the gradient of the log difference of two erfs.
% DEG2RAD Transform degrees to radians.
% NEGLOGLOGIT Function which returns the negative log of the logistic function.
% PDINV Invert a positive definite matrix.
% PREPAREPLOT Helper function for tidying up the plot before printing.
% PLOTMATRIX Fill a given axis with a matrix plot.
% TOKENISE Split a string into separate tokens.
% READSTRINGFROMFID Read an boolean from an FID.
% GRADIENTCHECK Check gradients of objective function.
% PRINTLATEXPLOT Print a plot to LaTeX.
% LNDIFFCUMGAUSSIAN Log of the difference between two cumulative Gaussians.
% READBOOLFROMFID Read a boolean from an FID.
% TABLEREAD Read in data which has column titles in the first line and separated values in each other line.
% INVCUMGAUSSIAN Computes inverse of the cumulative Gaussian.
% SCATTERPLOT 2-D scatter plot of labelled points.
% RAYLEIGHSAMP Sample from a Rayleigh with a given sigma.
% SPARSEDIAG Create a diagonal matrix that is sparse from a vector.
% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
% CELL2NUM Converts a cell array of strings to numbers.
% READINTFROMFID Read an integer from an FID.
% PRINTLATEXTEXT Print a text string to file for latex input.
% SAFESAVE Safe save
% TIMESERIESDATA make a time series data set with the given window length.
% TREEFINDROOTS Return indices of all root nodes in a tree structure.
% CUMGAMMA Cumulative distribution for gamma.
% WRITEVERSIONTOFID Writes a version to an FID.
% TREESWAPNODE Swap two nodes in the tree structure array.
% READVERSIONFROMFID Read version number from an FID.
% JITCHOL Do a Cholesky decomposition with jitter.
% GAUSSOVERDIFFCUMGAUSSIAN A Gaussian over difference of cumulative Gaussians.
% LNCUMGAUSSIAN log cumulative distribution for the normalised Gaussian.
% SIGMOID The sigmoid function
% ISOCTAVE Returns true if the software running is Octave.
% STRINGSIGFIGS Convert number to a string with a number of significant digits.
% GAUSSSAMP Sample from a Gaussian with a given covariance.
% WRITEDOUBLETOFID Writes a double to an FID.
% CENTERINGMATRIX returns the centering matrix for the given dimensionality.
% INVSIGMOID The inverse of the sigmoid function.
% NUMSF2STR Convert number to a string with a number of significant digits.
% TREEFINDCHILDREN Given a tree that lists only parents, add children.
% ROCCURVE Draw ROC curve and return labels.
% GETLINE Get a line from a file.
% LOGDET The log of the determinant when argument is positive definite.
% ZEROAXES A function to move the axes crossing point to the origin.
% WRITEBOOLTOFID Writes a boolean to an FID.
% GETSYMBOLS Get a cell array of different plot symbols.
% DIST1	Calculates absolute distance (i.e. L1 norm) between two sets of
% XLOGY z = x*log(y) returns zero if x=y=0
% NDLUTILTOOLBOXES Loads in toolboxes for NDLUTIL.
% KLDIVGAUSSIAN Give the KL divergence between two Gaussians.
% TREEFINDPARENTS Given a tree that lists only children, add parents.
% STACK Return column stacked vector of given matrix.
% ESCAPETEXT Add back slashes to escape existing backslashes in a text.
% GAMMAPDF PDF for the Gamma distribution.
