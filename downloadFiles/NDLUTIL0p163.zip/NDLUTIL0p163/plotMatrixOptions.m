function options = plotMatrixOptions

% PLOTMATRIXOPTIONS Default options for plot matrix.
%
%	Description:
%	options = plotMatrixOptions
%% 	plotMatrixOptions.m SVN version 2351
% 	last update 2012-06-11T12:56:45.308097Z

options.zoom.on = false;
options.zoom.row = [];
options.zoom.col = [];
options.highlight.on = false;
options.highlight.row = [];
options.highlight.col = [];
options.colormap = []; 
