function y=invsigmoid(x)

% INVSIGMOID The inverse of the sigmoid function.
%
% y=invsigmoid(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:30:10 2004
% NDLUTIL toolbox version 0.11






y = log(x./(1-x));