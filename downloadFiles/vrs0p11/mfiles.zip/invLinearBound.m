function y = invLinearBound(x)

% LINEARBOUND Constrains a parameter to be positive.
%
% y = invLinearBound(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Jun 15 14:38:11 2004
% OPTIMI toolbox version 0.11



limVal = 36;
index = find(x<-limVal);
y(index) = eps;
x(index) = NaN;
index = find(x<limVal);
y(index) = log(1+exp(x(index)));
x(index) = NaN;
index = find(~isnan(x));
y(index) = x(index);
