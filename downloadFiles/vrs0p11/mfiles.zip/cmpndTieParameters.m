function model = cmpndTieParameters(model, paramsList)

% CMPNDTIEPARAMETERS Tie parameters together.
%
% model = cmpndTieParameters(model, paramsList)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Jun 15 14:38:11 2004
% OPTIMI toolbox version 0.11




colToDelete = [];
for i = 1:length(paramsList)

  paramIndices=sort(paramsList{i});
  if any(paramIndices(1) == colToDelete)
    error('Parameter is already being tied')
  end
  for j = 2:length(paramIndices)

    model.paramGroups(paramIndices(j), paramIndices(1)) = 1;
    if any(paramIndices(j) == colToDelete)
      error('Parameter has already been tied')
    end
    colToDelete = [colToDelete paramIndices(j)];
  end
end

model.paramGroups(:, colToDelete) = [];
