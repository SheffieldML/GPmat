function y = sigmoid(x)

% SIGMOID The sigmoid function
%
% y = sigmoid(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:30:10 2004
% NDLUTIL toolbox version 0.11






y = ones(size(x))./(1+exp(-x));