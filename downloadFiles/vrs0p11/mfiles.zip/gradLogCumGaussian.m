function y = gradLogCumGaussian(x)

% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
%
% y = gradLogCumGaussian(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 16 15:09:29 2004
% NDLUTIL toolbox version 0.11






% Theoretically this is simply ngaussian(x)/cumGaussian(x) but there are
% problems in the tails of the distribution.

y = zeros(size(x));
index = find(x>0);
y(index) = ngaussian(x(index))./cumGaussian(x(index));
index = find(x<=0);
y(index) = 1./(sqrt(2*pi)*0.5*erfcx(-sqrt(2)/2*x(index)));
