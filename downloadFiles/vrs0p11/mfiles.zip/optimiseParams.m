function model = optimiseParams(component, optimiser, objective, ...
                                gradient, options, model, prior);

% OPTIMISEPARAMS Optimise parameters.
%
% model = optimiseParams(component, optimiser, objective, ...
%                                 gradient, options, model, prior);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Jun 15 14:38:11 2004
% OPTIMI toolbox version 0.11



% OPTIM

if nargin < 5
  prior = 0;
end


params = feval([component 'ExtractParam'], getfield(model, component));

if options(1)
  if length(params) > 20
    options(9) = 0;
  else
    options(9) = 1;
  end
end

params = feval(optimiser, objective, params, options, gradient, model, prior);

model = setfield(model, ...
                 component, ...
                 feval([component 'ExpandParam'], ...
                       getfield(model, component), ...
                       params));
