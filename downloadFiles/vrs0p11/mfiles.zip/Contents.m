% OPTIMI toolbox
% Version 0.11 Thursday, June 17, 2004 at 15:43:44
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.3 1.0 $
% 
% CMPNDTIEPARAMETERS Tie parameters together.
% EXPBOUND Constrains a parameter to be positive through exponentiation.
% EXPTRANSFORM Constrains a parameter to be positive through exponentiation.
% GRADFACTLINEARBOUND Gradient multiplier for linear bound.
% LINEARBOUND Constrains a parameter to be positive.
% LINEARBOUND Constrains a parameter to be positive.
% NEGLOGLOGIT Constrains a parameter to be positive.
% OPTIMISEPARAMS Optimise parameters.
% SIGMOIDBOUND Constrains a parameter to be between 0 and 1.
% SIGMOIDTRANSFORM Constrains a parameter to be between 0 and 1.
