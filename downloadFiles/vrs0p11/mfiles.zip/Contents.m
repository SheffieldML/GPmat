% NDLUTIL toolbox
% Version 0.11 Thursday, June 17, 2004 at 15:59:43
% Copyright (c) 2004 Neil D. Lawrence
% $Revision: 1.3 1.0 $
% 
% CUMGAUSSIAN Cumulative distribution for Gaussian.
% GAUSSOVERDIFFCUMGAUSSIAN A gaussian in x over the difference between two cumulative Gaussians. 
% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
% INVCUMGAUSSIAN Inverser of the cumulative Gaussian.
% INVSIGMOID The inverse of the sigmoid function.
% LNCUMGAUSSIAN log cumulative distribution for Gaussian.
% LOGDET The log of the determinant when argument is positive definite.
% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
% PDINV Computes the inverse of a positive definite matrix
% PREPAREPLOT Helper function for tidying up the plot before printing.
% ROCCURVE Draw ROC curve and return labels.
% SIGMOID The sigmoid function
