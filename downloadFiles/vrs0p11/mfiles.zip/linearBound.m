function y = linearBound(x, transform)

% LINEARBOUND Constrains a parameter to be positive.
%
% y = linearBound(x, transform)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Tue Jun 15 14:38:11 2004
% OPTIMI toolbox version 0.11



y = zeros(size(x));
limVal = 36;
switch transform
 case 'atox'
  index = find(x<-limVal);
  y(index) = eps;
  x(index) = NaN;
  index = find(x<limVal);
  y(index) = log(1+exp(x(index)));
  x(index) = NaN;
  index = find(~isnan(x));
  y(index) = x(index);
 case 'xtoa'
  index = find(x<limVal);
  y(index) = log(exp(x(index))-1);
  index = find(x>=limVal);
  y(index) = x(index);
 case 'gradfact'
  index = find(x>limVal);
  y(index) = 1;
  index = find(x<=limVal);
  y(index) = (exp(x(index))-1)./exp(x(index));
end
  