function options = linearOptions;

% LINEAROPTIONS Options for learning a linear model.
%
% options = linearOptions;
%

% Copyright (c) 2006 Neil D. Lawrence
% linearOptions.m version 1.1



options.activeFunc = 'linear';