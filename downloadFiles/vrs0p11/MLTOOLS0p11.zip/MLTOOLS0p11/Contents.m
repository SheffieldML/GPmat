% MLTOOLS toolbox
% Version 0.11		Friday 20 Jan 2006 at 18:45
% Copyright (c) 2006 Neil D. Lawrence
% 
% LINEARCREATE Create a linear model.
% ISOMAPEMBED Embed data set with Isomap.
% KPCAEMBED Embed data set with kernel PCA.
% LVMCLASSVISUALISE Callback function for visualising data in 2-D.
% IMAGEVISUALISE Helper code for showing an image during 2-D visualisation.
% KBREXPANDPARAM Update kernel based regression model with vector of parameters.
% KBREXTRACTPARAM Extract weights from a kernel based regression model.
% KBROPTIMISE Optimise a kernel based regression.
% KBROUT Obtain the output of the kernel based regression model.
% KBROUTPUTGRAD Evaluate derivatives of kernel based regression model outputs with respect to parameters.
% LINEAREXPANDPARAM Update linear model with vector of parameters.
% LINEAREXTRACTPARAM Extract weights from a linear model.
% LINEAROPTIMISE Optimise a linear model.
% LINEAROUT Obtain the output of the linear model.
% LINEAROUTPUTGRAD Evaluate derivatives of linear model outputs with respect to parameters.
% MAPPINGOPTIMISE Optimise the given model.
% MLPCREATE Wrapper for NETLAB's mlp `net'.
% MLPEXPANDPARAMS Update mlp model with new vector of parameters.
% MLPOUT Output of an MLP model (wrapper for the NETLAB function mlpfwd).
% MLPEXTRACTPARAMS Wrapper for NETLAB's mlppak.
% MLPOPTIMISE Optimise MLP for given inputs and outputs.
% MLPOUTPUTGRAD Evaluate derivatives of mlp model outputs with respect to parameters.
% MODELEXPANDPARAM Update a model structure with parameters.
% MODELEXTRACTPARAM Extract the parameters of a model.
% MODELOPTIMISE Optimise the given model.
% MODELOUT Give the output of a model for given X.
% MODELOUTPUTGRAD Compute derivatives with respect to params of model outputs.
% RBFCREATE Wrapper for NETLAB's rbf `net'.
% RBFEXPANDPARAMS Update rbf model with new vector of parameters.
% RBFEXTRACTPARAMS Wrapper for NETLAB's rbfpak.
% RBFOPTIMISE Optimise RBF for given inputs and outputs.
% RBFOUT Output of an RBF model (wrapper for the NETLAB function rbffwd).
% RBFOUTPUTGRAD Evaluate derivatives of rbf model outputs with respect to parameters.
% LVMSCATTERPLOT 2-D scatter plot of the latent points.
% PPCAEMBED Embed data set with probabilistic PCA.
% SPECTRUMMODIFY Helper code for visualisation of spectrum data.
% SPECTRUMVISUALISE Helper code for showing an spectrum during 2-D visualisation.
% KBRCREATE Create a kernel based regression model.
% VECTORMODIFY Helper code for visualisation of vectorial data.
% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
% LVMTWODPLOT Helper function for plotting the labels in 2-D.
% MODELLOGLIKELIHOODGRADIENTS Compute a model's gradients wrt log likelihood.
% MODELLOGLIKELIHOOD Compute a model log likelihood.
% LVMSCATTERPLOTCOLOR 2-D scatter plot of the latent points with color - for Swiss Roll data.
% MODELSAMP Give a sample from a model for given X.
% MODELDISPLAY Display a text output of a model.
% MLPDISPLAY Display the multi-layer perceptron model.
% MLPOPTIONS Options for the multi-layered perceptron.
% KBROPTIONS Kernel based regression options.
% RBFDISPLAY Display an RBF network.
% LINEAROPTIONS Options for learning a linear model.
% MODELCREATE Create a model of the specified type.
% RBFOPTIONS Default options for RBF network.
