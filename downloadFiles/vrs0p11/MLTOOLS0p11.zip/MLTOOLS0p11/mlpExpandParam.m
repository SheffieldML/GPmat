function model = mlpExpandParam(model, params)

% MLPEXPANDPARAMS Update mlp model with new vector of parameters.
%
% model = mlpExpandParam(model, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% mlpExpandParam.m version 1.2



model = mlpunpak(model, params);