function g = modelOutputGrad(model, X)

% MODELOUTPUTGRAD Compute derivatives with respect to params of model outputs.
%
% g = modelOutputGrad(model, X)
%

% Copyright (c) 2006 Neil D. Lawrence
% modelOutputGrad.m version 1.2



fhandle = str2func([model.type 'OutputGrad']);
g = fhandle(model, X);