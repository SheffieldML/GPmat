function model = modelLogLikelihood(model)

% MODELLOGLIKELIHOOD Compute a model log likelihood.
%
% model = modelLogLikelihood(model)
%

% Copyright (c) 2006 Neil D. Lawrence
% modelLogLikelihood.m version 1.1



fhandle = str2func([model.type 'LogLikelihood']);
model = fhandle(model);