function Y = kbrOut(model, X);

% KBROUT Obtain the output of the kernel based regression model.
%
% Y = kbrOut(model, X);
%

% Copyright (c) 2006 Neil D. Lawrence
% kbrOut.m version 1.2



numData = size(X, 1);
if ~isfield(model, 'bias') & isfield(model, 'b')
  model.bias = model.b;
end
Y = kernCompute(model.kern, X, model.X)*model.A+ones(numData, 1)*model.bias;
