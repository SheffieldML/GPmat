function model = modelExpandParam(model, params)

% MODELEXPANDPARAM Update a model structure with parameters.
%
% model = modelExpandParam(model, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% modelExpandParam.m version 1.2



fhandle = str2func([model.type 'ExpandParam']);
model = fhandle(model, params);