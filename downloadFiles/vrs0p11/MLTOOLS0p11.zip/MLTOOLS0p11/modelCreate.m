function model = modelCreate(type, numIn, numOut, varargin)

% MODELCREATE Create a model of the specified type.
%
% model = modelCreate(type, numIn, numOut, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence
% modelCreate.m version 1.1



fhandle = str2func([type, 'Create']);
model = fhandle(numIn, numOut, varargin{:});