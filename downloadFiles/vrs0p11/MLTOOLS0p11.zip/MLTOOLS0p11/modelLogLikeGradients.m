function g = modelLogLikeGradients(model)

% MODELLOGLIKELIHOODGRADIENTS Compute a model's gradients wrt log likelihood.
%
% g = modelLogLikeGradients(model)
%

% Copyright (c) 2006 Neil D. Lawrence
% modelLogLikeGradients.m version 1.1



fhandle = str2func([model.type 'LogLikeGradients']);
g = fhandle(model);