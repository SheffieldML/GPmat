function params = mlpExtractParam(model)

% MLPEXTRACTPARAMS Wrapper for NETLAB's mlppak.
%
% params = mlpExtractParam(model)
%

% Copyright (c) 2006 Neil D. Lawrence
% mlpExtractParam.m version 1.2



params = mlppak(model);