function model = linearOptimise(model, X, Y, varargin)

% LINEAROPTIMISE Optimise a linear model.
%
% model = linearOptimise(model, X, Y, varargin)
%

% Copyright (c) 2006 Neil D. Lawrence
% linearOptimise.m version 1.2



Xo = [X ones(size(X, 1), 1)];

W = pdinv(Xo'*Xo)*Xo'*Y;
model.W = W(1:end-1, :);
model.b = W(end, :);