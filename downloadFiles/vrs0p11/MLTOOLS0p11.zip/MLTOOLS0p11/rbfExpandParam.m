function model = rbfExpandParam(model, params)

% RBFEXPANDPARAMS Update rbf model with new vector of parameters.
%
% model = rbfExpandParam(model, params)
%

% Copyright (c) 2006 Neil D. Lawrence
% rbfExpandParam.m version 1.2



model = rbfunpak(model, params);