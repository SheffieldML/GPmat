function model = rbfCreate(inputDim, outputDim, options)

% RBFCREATE Wrapper for NETLAB's rbf `net'.
%
% model = rbfCreate(inputDim, outputDim, options)
%

% Copyright (c) 2006 Neil D. Lawrence
% rbfCreate.m version 1.2



model = rbf(inputDim, options.hiddenDim, outputDim, options.activeFunc, options.outFunc);
model.numParams = model.nwts;
model.inputDim = inputDim;
model.outputDim = outputDim;
