function [states, ll] = viterbiAlign(logTrans, logLike)

% VITERBIALIGN Compute the Viterbi alignment.
%
%	Description:
%
%	[STATES, LL] = VITERBIALIGN(LOGTRANS, LOGLIKE) computes the viterbi
%	alignment given a log transition probability matrix and a log
%	emission probability matrix.
%	 Returns:
%	  STATES - the most likely state at each point in the sequence.
%	  LL - the log likelihood of the most likely state sequence.
%	 Arguments:
%	  LOGTRANS - the logarithm of the transition probabilities (if
%	   exponentiated the sum of each row should be one, i.e. the matrix
%	   gives the transition probabilities from the ith state to the other
%	   states in the ith row.
%	  LOGLIKE - the logarithm of the emission probabilities. The
%	   different states are the rows of the matrix.
%	
%	
%
%	See also
%	


%	Copyright (c) 2006 Neil D. Lawrence
% 	viterbiAlign.m version 1.1


logProbPlace = zeros(size(logLike));
logProbPlace(:, 1) = logLike(:, 1);
ind(:, 1) = [1:size(logLike, 1)]';
for i = 1:size(logLike, 2)-1
  nextProbs = repmat(logProbPlace(:, i)...
                     +logLike(:, i), 1, size(logTrans, 2)) ...
      + logTrans;
  [logProbPlace(:, i+1), tempInd]= max(nextProbs, [], 2);
  ind(tempInd, i+1) = (1:size(ind, 1))';
end
states = zeros(1, size(logLike, 2));
[ll, states(end)] = max(logProbPlace(:, end));
for i = size(states, 2):-1:2
  states(i-1)= ind(states(i), i-1);
end
