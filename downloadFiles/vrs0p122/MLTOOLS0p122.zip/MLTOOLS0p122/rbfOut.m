function Y = rbfOut(model, X);

% RBFOUT Output of an RBF model (wrapper for the NETLAB function rbffwd).
%
%	Description:
%	Y = rbfOut(model, X);
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	rbfOut.m version 1.2


Y = rbffwd(model, X);