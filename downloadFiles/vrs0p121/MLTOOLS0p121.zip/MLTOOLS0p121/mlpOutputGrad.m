function g = mlpOutputGrad(model, X)

% MLPOUTPUTGRAD Evaluate derivatives of mlp model outputs with respect to parameters.
%
%	Description:
%	g = mlpOutputGrad(model, X)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpOutputGrad.m version 1.2


g = mlpderiv(model, X);