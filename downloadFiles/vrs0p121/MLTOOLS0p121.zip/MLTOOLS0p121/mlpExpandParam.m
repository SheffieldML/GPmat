function model = mlpExpandParam(model, params)

% MLPEXPANDPARAM Update mlp model with new vector of parameters.
%
%	Description:
%	model = mlpExpandParam(model, params)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpExpandParam.m version 1.3


model = mlpunpak(model, params);