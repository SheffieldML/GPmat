function [Y, Z] = mlpOut(model, X);

% MLPOUT Output of an MLP model (wrapper for the NETLAB function mlpfwd).
%
%	Description:
%
%	Y = MLPOUT(MODEL, X) gives the output of a multi-layer perceptron
%	model.
%	 Returns:
%	  Y - the output.
%	 Arguments:
%	  MODEL - the model for which the output is required.
%	  X - the input data for which the output is required.


%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpOut.m version 1.3

% SEEALSO : mlpfwd, mlp, modelOut

% COPYRIGHT : Neil D. Lawrence, 2006


if nargout > 1
  [Y, Z] = mlpfwd(model, X);
else
  Y = mlpfwd(model, X);
end