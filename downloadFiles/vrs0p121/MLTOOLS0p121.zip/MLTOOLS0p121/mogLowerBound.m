function lll = mogLowerBound(model)
