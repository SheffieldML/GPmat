function linearDisplay(model, spacing)

% LINEARDISPLAY Display a linear model.
%
%	Description:
%	linearDisplay(model, spacing)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	linearDisplay.m version 1.1


if nargin > 1
  spacing = repmat(32, 1, spacing);
else
  spacing = [];
end
spacing = char(spacing);
fprintf(spacing);
fprintf('Model model:\n')
fprintf(spacing);
fprintf('  Input dimension: %d\n', model.inputDim);
fprintf(spacing);
fprintf('  Output dimension: %d\n', model.outputDim);
