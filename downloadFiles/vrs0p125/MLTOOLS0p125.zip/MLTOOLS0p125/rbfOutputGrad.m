function g = rbfOutputGrad(model, X)

% RBFOUTPUTGRAD Evaluate derivatives of rbf model outputs with respect to parameters.
%
%	Description:
%	g = rbfOutputGrad(model, X)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	rbfOutputGrad.m version 1.2

g = rbfderiv(model, X);