function g = mlpLogLikeHessian(model)

% MLPLOGLIKEHESSIAN Multi-layer perceptron Hessian.
%
%	Description:
%
%	G = MLPLOGLIKEHESSIAN(MODEL) computes the Hessian of the log
%	likelihood of a multi-layer perceptron with respect to the
%	parameters. This is done by wrapping the mlpgrad command.
%	 Returns:
%	  G - the Hessian of the model log likelihood.
%	 Arguments:
%	  MODEL - the model structure for computing the log likelihood.
%	
%
%	See also
%	MODELLOGLIKEIHOOD, MLPGRAD


%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpLogLikeHessian.m version 1.1


g = -mlphess(model, model.X, model.y);
