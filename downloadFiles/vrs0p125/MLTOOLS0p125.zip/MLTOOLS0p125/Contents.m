% MLTOOLS toolbox
% Version 0.125		04-Feb-2007
% Copyright (c) 2007 Neil D. Lawrence
% 
% DEMMPPCA1 Demonstrate MPPCA on a artificial dataset.
% IMAGEMODIFY Helper code for visualisation of image data.
% IMAGEVISUALISE Helper code for showing an image during 2-D visualisation.
% ISOMAPEMBED Embed data set with Isomap.
% KBRCREATE Create a KBR model.
% KBRDISPLAY Display parameters of the KBR model.
% KBREXPANDPARAM Create model structure from KBR model's parameters.
% KBREXTRACTPARAM Extract parameters from the KBR model structure.
% KBROPTIMISE Optimise a KBR model.
% KBROPTIONS Create a default options structure for the KBR model.
% KBROUT Compute the output of a KBR model given the structure and input X.
% KBROUTPUTGRAD Evaluate derivatives of KBR model outputs with respect to parameters.
% KBRPARAMINIT KBR model parameter initialisation.
% KPCAEMBED Embed data set with kernel PCA.
% LINEARCREATE Create a linear model.
% LINEARDISPLAY Display a linear model.
% LINEAREXPANDPARAM Update linear model with vector of parameters.
% LINEAREXTRACTPARAM Extract weights from a linear model.
% LINEARLOGLIKEGRADIENTS Linear model gradients.
% LINEARLOGLIKELIHOOD Linear model log likelihood.
% LINEAROPTIMISE Optimise a linear model.
% LINEAROPTIONS Options for learning a linear model.
% LINEAROUT Obtain the output of the linear model.
% LINEAROUTPUTGRAD Evaluate derivatives of linear model outputs with respect to parameters.
% LINEAROUTPUTGRADX Evaluate derivatives of linear model outputs with respect to inputs.
% LINEARPARAMINIT Initialise the parameters of an LINEAR model.
% LLEEMBED Embed data set with LLE.
% LVMCLASSVISUALISE Callback function for visualising data in 2-D.
% LVMSCATTERPLOT 2-D scatter plot of the latent points.
% LVMSCATTERPLOTCOLOR 2-D scatter plot of the latent points with color - for Swiss Roll data.
% LVMTWODPLOT Helper function for plotting the labels in 2-D.
% MAPPINGOPTIMISE Optimise the given model.
% MLPCREATE Wrapper for NETLAB's mlp `net'.
% MLPDISPLAY Display the multi-layer perceptron model.
% MLPEXPANDPARAM Update mlp model with new vector of parameters.
% MLPEXTRACTPARAM Extract weights and biases from an MLP.
% MLPLOGLIKEGRADIENTS Multi-layer perceptron gradients.
% MLPLOGLIKEHESSIAN Multi-layer perceptron Hessian.
% MLPLOGLIKELIHOOD Multi-layer perceptron log likelihood.
% MLPOPTIMISE Optimise MLP for given inputs and outputs.
% MLPOPTIONS Options for the multi-layered perceptron.
% MLPOUT Output of an MLP model (wrapper for the NETLAB function mlpfwd).
% MLPOUTPUTGRAD Evaluate derivatives of mlp model outputs with respect to parameters.
% MLPOUTPUTGRADX Evaluate derivatives of mlp model outputs with respect to inputs.
% MLPPARAMINIT Initialise the parameters of an MLP model.
% MLTOOLSTOOLBOXES Load in the relevant toolboxes for the MLTOOLS.
% MODELCREATE Create a model of the specified type.
% MODELDISPLAY Display a text output of a model.
% MODELEXPANDPARAM Update a model structure with parameters.
% MODELEXTRACTPARAM Extract the parameters of a model.
% MODELGRADIENT Gradient of error function to minimise for given model.
% MODELGRADIENTCHECK Check gradients of given model.
% MODELHESSIAN Hessian of error function to minimise for given model.
% MODELLOGLIKEGRADIENTS Compute a model's gradients wrt log likelihood.
% MODELLOGLIKELIHOOD Compute a model log likelihood.
% MODELOBJECTIVE Objective function to minimise for given model.
% MODELOPTIMISE Optimise the given model.
% MODELOPTIONS Returns a default options structure for the given model.
% MODELOUT Give the output of a model for given X.
% MODELOUTPUTGRAD Compute derivatives with respect to params of model outputs.
% MODELOUTPUTGRADX Compute derivatives with respect to model inputs of model outputs.
% MODELPARAMINIT Initialise the parameters of the model.
% MODELPOINTLOGLIKELIHOOD Compute the log likelihood of a given point.
% MODELSAMP Give a sample from a model for given X.
% MODELTEST Run some tests on the specified model.
% MODELTIEPARAM Tie parameters of a model together.
% MOGCREATE Create a mixtures of Gaussians model.
% MOGESTEP Do an E-step on an MOG model.
% MOGLOWERBOUND Computes lower bound on log likelihood for an MOG model.
% MOGOPTIMISE Optimise an MOG model.
% MOGOPTIONS Sets the default options structure for MOG models.
% MOGUPDATECOVARIANCE Update the covariances of an MOG model.
% MOGUPDATEMEAN Update the means of an MOG model.
% MOGUPDATEPRIOR Update the priors of an MOG model.
% MULTIMODELCREATE Create a MULTIMODEL model.
% MULTIMODELDISPLAY Display parameters of the MULTIMODEL model.
% MULTIMODELEXPANDPARAM Create model structure from MULTIMODEL model's parameters.
% MULTIMODELEXTRACTPARAM Extract parameters from the MULTIMODEL model structure.
% MULTIMODELLOGLIKEGRADIENTS Gradient of MULTIMODEL model log likelihood with respect to parameters.
% MULTIMODELLOGLIKELIHOOD Log likelihood of MULTIMODEL model.
% MULTIMODELOPTIONS Create a default options structure for the MULTIMODEL model.
% MULTIMODELPARAMINIT MULTIMODEL model parameter initialisation.
% PPCAEMBED Embed data set with probabilistic PCA.
% RBFCREATE Wrapper for NETLAB's rbf `net'.
% RBFDISPLAY Display an RBF network.
% RBFEXPANDPARAM Update rbf model with new vector of parameters.
% RBFEXTRACTPARAM Wrapper for NETLAB's rbfpak.
% RBFOPTIMISE Optimise RBF for given inputs and outputs.
% RBFOPTIONS Default options for RBF network.
% RBFOUT Output of an RBF model (wrapper for the NETLAB function rbffwd).
% RBFOUTPUTGRAD Evaluate derivatives of rbf model outputs with respect to parameters.
% RBFPERIODICCREATE Create a RBFPERIODIC model.
% RBFPERIODICDISPLAY Display parameters of the RBFPERIODIC model.
% RBFPERIODICEXPANDPARAM Create model structure from RBFPERIODIC model's parameters.
% RBFPERIODICEXTRACTPARAM Extract parameters from the RBFPERIODIC model structure.
% RBFPERIODICLOGLIKEGRADIENTS Gradient of RBFPERIODIC model log likelihood with respect to parameters.
% RBFPERIODICLOGLIKELIHOOD Log likelihood of RBFPERIODIC model.
% RBFPERIODICOPTIONS Create a default options structure for the RBFPERIODIC model.
% RBFPERIODICOUT Compute the output of a RBFPERIODIC model given the structure and input X.
% RBFPERIODICOUTPUTGRAD Evaluate derivatives of RBFPERIODIC model outputs with respect to parameters.
% RBFPERIODICOUTPUTGRADX Evaluate derivatives of a RBFPERIODIC model's output with respect to inputs.
% RBFPERIODICPARAMINIT RBFPERIODIC model parameter initialisation.
% SMALLRANDEMBED Embed data set with small random values.
% SPECTRUMMODIFY Helper code for visualisation of spectrum data.
% SPECTRUMVISUALISE Helper code for showing an spectrum during 2-D visualisation.
% VECTORMODIFY Helper code for visualisation of vectorial data.
% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
% VITERBIALIGN Compute the Viterbi alignment.
