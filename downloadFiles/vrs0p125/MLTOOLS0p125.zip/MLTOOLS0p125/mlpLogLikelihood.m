function ll = mlpLogLikelihood(model)

% MLPLOGLIKELIHOOD Multi-layer perceptron log likelihood.
%
%	Description:
%
%	LL = MLPLOGLIKELIHOOD(MODEL) computes the log likelihood of a
%	multi-layer perceptron model. This is done by wrapping the mlperr
%	command.
%	 Returns:
%	  LL - the model log likelihood.
%	 Arguments:
%	  MODEL - the model structure for computing the log likelihood.
%	
%
%	See also
%	MODELLOGLIKEIHOOD, MLPERR


%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpLogLikelihood.m version 1.1


ll = -mlperr(model, model.X, model.y);
