MOCAP software
Version 0.134		Tuesday 12 Aug 2008 at 21:32

This toolbox allows MATLAB to read in and write bvh files and read acclaim files. There are also routines for visualising the files in MATLAB.

Version 0.134 Release Notes
---------------------------

Bug fix release, a bug in bvh2xyz meant that if a position was included in the bvh skeleton structure for non-root nodes, the xyz positions were computed incorrectly. Thanks to Richard Widgery and Christopher Hulbert for identifying this problem. 

horse.bvh removed due to copyright reasons. To obtain a license for this file, and plenty of other motion capture data of horses, please contact Richard Widgery of Kinetic Impulse.

Version 0.133 Release Notes
---------------------------

Bug fix release, to deal with bugs in mocapResultsCppBvh, thanks to Cedric Vanaken for pointing out the problem.

Version 0.132 Release Notes
---------------------------

Moved tree handling code into NDLUTIL toolbox, version 0.156.

Version 0.131 Release Notes
---------------------------

The axis display for visualising the data gave the limbs on the wrong side (this is a problem of definition of the axis system). It was fixed by placing 

axis ij 

in the skeVisualise.m file. Thanks to Heike Vallery for pointing out this error.

Version 0.13 Release Notes
--------------------------

Added the ability to read motion capture files in the Acclaim format (asf and amc) to facilitate using the CMU Motion Capture database.

Version 0.12 Release Notes
--------------------------

mocapResultsCppBvh now uses the FGPLVM toolbox rather than the GPLVM toolbox.

Version 0.11 Release Notes
--------------------------

There were some missing files in the previous version that have been added in this version.

Version 0.1 Release Notes
-------------------------

First release of the toolbox to coincide with release of C++ GPLVM code.


MATLAB Files
------------

Matlab files associated with the toolbox are:

bvhPlayData.m: Play bvh motion capture data.
smoothAngleChannels.m: Try and remove artificial discontinuities associated with angles.
bvhConnectionMatrix.m: Compute the connection matrix for the structure.
acclaimPlayFile.m: Play motion capture data from a asf and amc file.
bvhReadFile.m: Reads a bvh file into a tree structure.
bvhModify.m: Helper code for visualisation of bvh data.
bvhPlayFile.m: Play motion capture data from a bvh file.
skelReverseLookup.m: Return the number associated with the joint name.
acclaimLoadChannels.m: Load the channels from an AMC file.
mocapToolboxes.m: Toolboxes required by the MOCAP toolbox.
acclaim2xyz.m: Compute XYZ values given skeleton structure and channels.
skelVisualise.m: For drawing a skel representation of 3-D data.
skelConnectionMatrix.m: Compute the connection matrix for the structure.
stickModify.m: Helper code for visualisation of a stick man.
rotationMatrix.m: Compute the rotation matrix for an angle in each direction.
skel2xyz.m: Compute XYZ values given skeleton structure and channels.
mocapResultsCppBvh.m: Load results from cpp file and visualise as a bvh format.
skelPlayData.m: Play skel motion capture data.
bvhVisualise.m: For updating a bvh representation of 3-D data.
bvh2xyz.m: Compute XYZ values given structure and channels.
acclaimReadSkel.m: Reads an ASF file into a skeleton structure.
bvhWriteFile.m: Write a bvh file from a given structure and channels.
skelModify.m: Update visualisation of skeleton data.
stickVisualise.m: For drawing a stick representation of 3-D data.
