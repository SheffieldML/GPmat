% MOCAP toolbox
% Version 0.134		12-Aug-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% BVHPLAYDATA Play bvh motion capture data.
% SMOOTHANGLECHANNELS Try and remove artificial discontinuities associated with angles.
% BVHCONNECTIONMATRIX Compute the connection matrix for the structure.
% ACCLAIMPLAYFILE Play motion capture data from a asf and amc file.
% BVHREADFILE Reads a bvh file into a tree structure.
% BVHMODIFY Helper code for visualisation of bvh data.
% BVHPLAYFILE Play motion capture data from a bvh file.
% SKELREVERSELOOKUP Return the number associated with the joint name.
% ACCLAIMLOADCHANNELS Load the channels from an AMC file.
% MOCAPTOOLBOXES Toolboxes required by the MOCAP toolbox.
% ACCLAIM2XYZ Compute XYZ values given skeleton structure and channels.
% SKELVISUALISE For drawing a skel representation of 3-D data.
% SKELCONNECTIONMATRIX Compute the connection matrix for the structure.
% STICKMODIFY Helper code for visualisation of a stick man.
% ROTATIONMATRIX Compute the rotation matrix for an angle in each direction.
% SKEL2XYZ Compute XYZ values given skeleton structure and channels.
% MOCAPRESULTSCPPBVH Load results from cpp file and visualise as a bvh format.
% SKELPLAYDATA Play skel motion capture data.
% BVHVISUALISE For updating a bvh representation of 3-D data.
% BVH2XYZ Compute XYZ values given structure and channels.
% ACCLAIMREADSKEL Reads an ASF file into a skeleton structure.
% BVHWRITEFILE Write a bvh file from a given structure and channels.
% SKELMODIFY Update visualisation of skeleton data.
% STICKVISUALISE For drawing a stick representation of 3-D data.
