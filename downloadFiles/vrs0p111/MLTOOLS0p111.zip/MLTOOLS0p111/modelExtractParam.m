function params = modelExtractParam(model)

% MODELEXTRACTPARAM Extract the parameters of a model.
%
% params = modelExtractParam(model)
%

% Copyright (c) 2006 Neil D. Lawrence
% modelExtractParam.m version 1.2



fhandle = str2func([model.type 'ExtractParam']);
params = fhandle(model);