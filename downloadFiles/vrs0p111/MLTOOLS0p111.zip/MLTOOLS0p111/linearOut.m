function Y = linearOut(model, X);

% LINEAROUT Obtain the output of the linear model.
%
% Y = linearOut(model, X);
%

% Copyright (c) 2006 Neil D. Lawrence
% linearOut.m version 1.2



numData = size(X, 1);
Y = X*model.W + ones(numData, 1)*model.b;
