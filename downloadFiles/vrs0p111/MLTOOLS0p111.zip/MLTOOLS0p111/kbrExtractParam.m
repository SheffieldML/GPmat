function params = kbrExtractParam(model);

% KBREXTRACTPARAM Extract weights from a kernel based regression model.
%
% params = kbrExtractParam(model);
%

% Copyright (c) 2006 Neil D. Lawrence
% kbrExtractParam.m version 1.3



params = [model.A(:)' model.bias];