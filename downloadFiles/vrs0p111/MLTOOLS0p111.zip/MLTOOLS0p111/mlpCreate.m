function model = mlpCreate(inputDim, outputDim, options)

% MLPCREATE Wrapper for NETLAB's mlp `net'.
%
% model = mlpCreate(inputDim, outputDim, options)
%

% Copyright (c) 2006 Neil D. Lawrence
% mlpCreate.m version 1.2



model = mlp(inputDim, options.hiddenDim, outputDim, options.activeFunc);
model.numParams = model.nwts;
model.inputDim = inputDim;
model.outputDim = outputDim;
