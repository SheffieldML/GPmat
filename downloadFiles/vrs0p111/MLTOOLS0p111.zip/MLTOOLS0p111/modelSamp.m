function Y = modelSamp(model, X)

% MODELSAMP Give a sample from a model for given X.
%
% Y = modelSamp(model, X)
%

% Copyright (c) 2006 Neil D. Lawrence
% modelSamp.m version 1.1



fhandle = str2func([model.type 'Samp']);
Y = fhandle(model, X);