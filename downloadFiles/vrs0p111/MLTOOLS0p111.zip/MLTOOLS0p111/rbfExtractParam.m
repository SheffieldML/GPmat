function params = rbfExtractParam(model)

% RBFEXTRACTPARAMS Wrapper for NETLAB's rbfpak.
%
% params = rbfExtractParam(model)
%

% Copyright (c) 2006 Neil D. Lawrence
% rbfExtractParam.m version 1.2



params = rbfpak(model);