function model = modelOptimise(model)

% MODELOPTIMISE Optimise the given model.
%
% model = modelOptimise(model)
%

% Copyright (c) 2006 Neil D. Lawrence
% modelOptimise.m version 1.2



fhandle = str2func([model.type 'Optimise']);
model = fhandle(model);