function [params, names] = multimodelExtractParam(model)

% MULTIMODELEXTRACTPARAM Extract parameters from the MULTIMODEL model structure.
%
%	Description:
%
%	PARAM = MULTIMODELEXTRACTPARAM(MODEL) extracts parameters from the
%	multi-task learning wrapper model structure into a vector of
%	parameters for optimisation.
%	 Returns:
%	  PARAM - vector of parameters extracted from the model.
%	 Arguments:
%	  MODEL - the model structure containing the parameters to be
%	   extracted.
%
%	[PARAM, NAMES] = MULTIMODELEXTRACTPARAM(MODEL) extracts parameters
%	and parameter names from the multi-task learning wrapper model
%	structure.
%	 Returns:
%	  PARAM - vector of parameters extracted from the model.
%	  NAMES - cell array of strings containing names for each parameter.
%	 Arguments:
%	  MODEL - the model structure containing the parameters to be
%	   extracted.
%	
%	
%
%	See also
%	% SEEALSO MULTIMODELCREATE, MULTIMODELEXPANDPARAM, MODELEXTRACTPARAM, SCG, CONJGRAD


%	Copyright (c) 2007 Neil D. Lawrence
% 	multimodelExtractParam.m CVS version 1.1
% 	multimodelExtractParam.m SVN version 24
% 	last update 2007-11-03T14:24:25.000000Z
[params, names] = modelExtractParam(model.comp{1});
