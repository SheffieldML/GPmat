function model = multimodelCreate(inputDim, outputDim, varargin)

% MULTIMODELCREATE Create a MULTIMODEL model.
%
%	Description:
%	The MULTIMODEL is a way of performing multi-task learning by sharing
%	model parameters across a range of models. The default (simple)
%	assumption is that the data is conditionally independent given the
%	parameters, i.e. the log likelihood is the sum of the log likelihood of
%	the models.
%	
%	
%
%	MODEL = MULTIMODELCREATE(INPUTDIM, OUTPUTDIM, OPTIONS) creates a
%	multi-task learning wrapper model structure given an options
%	structure.
%	 Returns:
%	  MODEL - the model structure with the default parameters placed in.
%	 Arguments:
%	  INPUTDIM - the input dimension of the model.
%	  OUTPUTDIM - the output dimension of the model.
%	  OPTIONS - an options structure that determines the form of the
%	   model.
%	
%
%	See also
%	MODELCREATE, MULTIMODELOPTIONS, MULTIMODELPARAMINIT, MODELCREATE


%	Copyright (c) 2007 Neil D. Lawrence
% 	multimodelCreate.m CVS version 1.1
% 	multimodelCreate.m SVN version 24
% 	last update 2007-11-03T14:24:24.000000Z
options = varargin{end};
model.numModels = options.numModels;
model.type = 'multimodel';
model.compType = options.type;
model.inputDim = inputDim;
model.outputDim = outputDim;
for i = 1:model.numModels
  varargput = cell(1, length(varargin)-1);
  for j = 1:length(varargput)
    varargput{j} = varargin{j}{i};
  end
  model.comp{i} = modelCreate(model.compType, inputDim, outputDim, ...
                              varargput{:}, options.compOptions);
end
if isfield(model.comp{i}, 'numParams');
  model.numParams = model.comp{1}.numParams;
else
  model.numParams = length(modelExtractParam(model.comp{1}));
end
