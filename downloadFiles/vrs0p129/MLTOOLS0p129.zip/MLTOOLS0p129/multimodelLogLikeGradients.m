function g = multimodelLogLikeGradients(model)

% MULTIMODELLOGLIKEGRADIENTS Gradient of MULTIMODEL model log likelihood with respect to parameters.
%
%	Description:
%
%	G = MULTIMODELLOGLIKEGRADIENTS(MODEL) computes the gradient of the
%	multi-task learning wrapper model's log likelihood with respect to
%	the parameters.
%	 Returns:
%	  G - the returned gradients.
%	 Arguments:
%	  MODEL - model structure for which gradients are being computed.
%	
%
%	See also
%	% SEEALSO MULTIMODELCREATE, MULTIMODELLOGLIKELIHOOD, MODELLOGLIKEGRADIENTS


%	Copyright (c) 2007 Neil D. Lawrence
% 	multimodelLogLikeGradients.m CVS version 1.1
% 	multimodelLogLikeGradients.m SVN version 24
% 	last update 2007-11-03T14:24:25.000000Z

g = zeros(1, model.numParams);
for i = 1:length(model.comp)
  g = g + modelLogLikeGradients(model.comp{i});
end