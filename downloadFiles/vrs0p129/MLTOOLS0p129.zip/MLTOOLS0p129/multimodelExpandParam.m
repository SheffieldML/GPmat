function model = multimodelExpandParam(model, params)

% MULTIMODELEXPANDPARAM Create model structure from MULTIMODEL model's parameters.
%
%	Description:
%
%	MODEL = MULTIMODELEXPANDPARAM(MODEL, PARAM) returns a multi-task
%	learning wrapper model structure filled with the parameters in the
%	given vector. This is used as a helper function to enable parameters
%	to be optimised in, for example, the NETLAB optimisation functions.
%	 Returns:
%	  MODEL - model structure with the given parameters in the relevant
%	   locations.
%	 Arguments:
%	  MODEL - the model structure in which the parameters are to be
%	   placed.
%	  PARAM - vector of parameters which are to be placed in the model
%	   structure.
%	
%
%	See also
%	MULTIMODELCREATE, MULTIMODELEXTRACTPARAM, MODELEXPANDPARAM


%	Copyright (c) 2007 Neil D. Lawrence
% 	multimodelExpandParam.m CVS version 1.1
% 	multimodelExpandParam.m SVN version 24
% 	last update 2007-11-03T14:24:25.000000Z

for i = 1:length(model.comp)
  model.comp{i} = modelExpandParam(model.comp{i}, params);
end