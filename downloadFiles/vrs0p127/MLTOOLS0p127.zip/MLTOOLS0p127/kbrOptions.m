function options = kbrOptions(X)

% KBROPTIONS Create a default options structure for the KBR model.
%
%	Description:
%
%	OPTIONS = KBROPTIONS creates a default options structure for the
%	kernel based regression model structure.
%	 Returns:
%	  OPTIONS - the default options structure.
%	
%
%	See also
%	KBRCREATE, MODELOPTIONS


%	Copyright (c) 2005, 2006 Neil D. Lawrence
% 	kbrOptions.m version 1.2


options.kern = 'rbf';
options.X = X;
