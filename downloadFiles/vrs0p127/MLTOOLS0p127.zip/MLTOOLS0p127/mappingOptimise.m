function model = mappingOptimise(model, X, Y, varargin)

% MAPPINGOPTIMISE Optimise the given model.
%
%	Description:
%	model = mappingOptimise(model, X, Y, varargin)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	mappingOptimise.m version 1.2


fhandle = str2func([model.type 'Optimise']);
model = fhandle(model, X, Y, varargin{:});