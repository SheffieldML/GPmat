function Y = kbrOut(model, X);

% KBROUT Compute the output of a KBR model given the structure and input X.
%
%	Description:
%
%	Y = KBROUT(MODEL, X) computes the model parameters for the kernel
%	based regression model given inputs associated with rows and
%	columns.
%	 Returns:
%	  Y - the output results.
%	 Arguments:
%	  MODEL - the model structure for which the output is computed.
%	  X - the input data.
%	
%
%	See also
%	KBRCREATE, MODELCOMPUTE, MODELCREATE, KBREXPANDPARAM, KBREXTRACTPARAM


%	Copyright (c) 2005, 2006 Neil D. Lawrence
% 	kbrOut.m version 1.3


numData = size(X, 1);
if ~isfield(model, 'bias') & isfield(model, 'b')
  model.bias = model.b;
end
Y = kernCompute(model.kern, X, model.X)*model.A+ones(numData, 1)*model.bias;
