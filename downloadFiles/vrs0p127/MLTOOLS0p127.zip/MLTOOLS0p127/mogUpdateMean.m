function model = mogUpdateMean(model)

% MOGUPDATEMEAN Update the means of an MOG model.
%
%	Description:
%
%	MODEL = MOGUPDATEMEAN(MODEL) updates the mean vectors of a mixtures
%	of Gaussians model.
%	 Returns:
%	  MODEL - the model with updated means.
%	 Arguments:
%	  MODEL - the model which is to be updated.
%	
%
%	See also
%	MOGCREATE, MOGUPDATECOVARIANCE, MOGESTEP


%	Copyright (c) 2006 Neil D. Lawrence
% 	mogUpdateMean.m version 1.1


for i = 1:model.m
  for j = 1:model.d
    model.mean(i, j) = model.posterior(:, i)'*model.Y(:, ...
                                                      j)/sum(model.posterior(:, i));
  end    
end

