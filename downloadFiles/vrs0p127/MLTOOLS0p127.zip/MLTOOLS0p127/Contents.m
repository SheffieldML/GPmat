% MLTOOLS toolbox
% Version 0.127		22-May-2007
% Copyright (c) 2007 Neil D. Lawrence
% 
% MULTIMODELOPTIONS Create a default options structure for the MULTIMODEL model.
% LLEEMBED Embed data set with LLE.
% RBFPERIODICOUTPUTGRAD Evaluate derivatives of RBFPERIODIC model outputs with respect to parameters.
% RBFOPTIMISE Optimise RBF for given inputs and outputs.
% MODELADDDYNAMICS Add a dynamics kernel to the model.
% MODELOUTPUTGRADX Compute derivatives with respect to model inputs of model outputs.
% RBFPERIODICEXTRACTPARAM Extract parameters from the RBFPERIODIC model structure.
% RBFPERIODICOUTPUTGRADX Evaluate derivatives of a RBFPERIODIC model's output with respect to inputs.
% MULTIMODELEXTRACTPARAM Extract parameters from the MULTIMODEL model structure.
% RBFPERIODICEXPANDPARAM Create model structure from RBFPERIODIC model's parameters.
% MULTIMODELEXPANDPARAM Create model structure from MULTIMODEL model's parameters.
% RBFPERIODICLOGLIKELIHOOD Log likelihood of RBFPERIODIC model.
% MOGESTEP Do an E-step on an MOG model.
% KBREXPANDPARAM Create model structure from KBR model's parameters.
% LINEAROUTPUTGRADX Evaluate derivatives of linear model outputs with respect to inputs.
% RBFEXPANDPARAM Update rbf model with new vector of parameters.
% KBROPTIMISE Optimise a KBR model.
% SPECTRUMVISUALISE Helper code for showing an spectrum during 2-D visualisation.
% MLPEXTRACTPARAM Extract weights and biases from an MLP.
% IMAGEMODIFY Helper code for visualisation of image data.
% LINEARPARAMINIT Initialise the parameters of an LINEAR model.
% MODELEXTRACTPARAM Extract the parameters of a model.
% MLPOUT Output of an MLP model.
% MULTIMODELLOGLIKELIHOOD Log likelihood of MULTIMODEL model.
% MODELEXPANDPARAM Update a model structure with parameters.
% PPCAEMBED Embed data set with probabilistic PCA.
% KBRDISPLAY Display parameters of the KBR model.
% MAPPINGOPTIMISE Optimise the given model.
% MLPOUTPUTGRAD Evaluate derivatives of mlp model outputs with respect to parameters.
% MOGOPTIONS Sets the default options structure for MOG models.
% VITERBIALIGN Compute the Viterbi alignment.
% RBFOUT Output of an RBF model (wrapper for the NETLAB function rbffwd).
% KBROUT Compute the output of a KBR model given the structure and input X.
% MLPEXPANDPARAM Update mlp model with new vector of parameters.
% MODELGRADIENT Gradient of error function to minimise for given model.
% RBFOUTPUTGRAD Evaluate derivatives of rbf model outputs with respect to parameters.
% KBROUTPUTGRAD Evaluate derivatives of KBR model outputs with respect to parameters.
% MODELOPTIMISE Optimise the given model.
% MULTIMODELDISPLAY Display parameters of the MULTIMODEL model.
% MODELTIEPARAM Tie parameters of a model together.
% LINEAROUT Obtain the output of the linear model.
% MLPPARAMINIT Initialise the parameters of an MLP model.
% RBFPERIODICOUT Compute the output of a RBFPERIODIC model given the structure and input X.
% LINEAROUTPUTGRAD Evaluate derivatives of linear model outputs with respect to parameters.
% LINEAREXTRACTPARAM Extract weights from a linear model.
% IMAGEVISUALISE Helper code for showing an image during 2-D visualisation.
% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
% MODELPARAMINIT Initialise the parameters of the model.
% MLPLOGLIKEGRADIENTS Multi-layer perceptron gradients.
% MLPOPTIONS Options for the multi-layered perceptron.
% MODELOUT Give the output of a model for given X.
% MOGOPTIMISE Optimise an MOG model.
% MLPCREATE Multi-layer peceptron model.
% LINEARCREATE Create a linear model.
% MOGLOWERBOUND Computes lower bound on log likelihood for an MOG model.
% MODELOUTPUTGRAD Compute derivatives with respect to params of model outputs.
% SMALLRANDEMBED Embed data set with small random values.
% RBFPERIODICDISPLAY Display parameters of the RBFPERIODIC model.
% MODELCREATE Create a model of the specified type.
% LINEAROPTIMISE Optimise a linear model.
% MULTIMODELCREATE Create a MULTIMODEL model.
% KBROPTIONS Create a default options structure for the KBR model.
% RBFPERIODICOPTIONS Create a default options structure for the RBFPERIODIC model.
% MLPDISPLAY Display the multi-layer perceptron model.
% LVMCLASSVISUALISE Callback function for visualising data in 2-D.
% VECTORMODIFY Helper code for visualisation of vectorial data.
% RBFOPTIONS Default options for RBF network.
% MODELLOGLIKEGRADIENTS Compute a model's gradients wrt log likelihood.
% MODELLOGLIKELIHOOD Compute a model log likelihood.
% MOGUPDATEPRIOR Update the priors of an MOG model.
% LINEARLOGLIKELIHOOD Linear model log likelihood.
% MODELDISPLAY Display a text output of a model.
% MLPOPTIMISE Optimise MLP for given inputs and outputs.
% MLPLOGLIKELIHOOD Multi-layer perceptron log likelihood.
% MLPOUTPUTGRADX Evaluate derivatives of mlp model outputs with respect to inputs.
% MLTOOLSTOOLBOXES Load in the relevant toolboxes for the MLTOOLS.
% LINEAROPTIONS Options for learning a linear model.
% RBFPERIODICCREATE Create a RBFPERIODIC model.
% MODELGRADIENTCHECK Check gradients of given model.
% LVMSCATTERPLOTCOLOR 2-D scatter plot of the latent points with color - for Swiss Roll data.
% MULTIMODELPARAMINIT MULTIMODEL model parameter initialisation.
% LVMTWODPLOT Helper function for plotting the labels in 2-D.
% LINEAREXPANDPARAM Update linear model with vector of parameters.
% ISOMAPEMBED Embed data set with Isomap.
% MOGCREATE Create a mixtures of Gaussians model.
% RBFEXTRACTPARAM Wrapper for NETLAB's rbfpak.
% MLPLOGLIKEHESSIAN Multi-layer perceptron Hessian.
% RBFPERIODICPARAMINIT RBFPERIODIC model parameter initialisation.
% MODELSAMP Give a sample from a model for given X.
% RBFCREATE Wrapper for NETLAB's rbf `net'.
% MOGUPDATEMEAN Update the means of an MOG model.
% MODELOPTIONS Returns a default options structure for the given model.
% MODELTEST Run some tests on the specified model.
% KBRPARAMINIT KBR model parameter initialisation.
% LVMSCATTERPLOT 2-D scatter plot of the latent points.
% MULTIMODELLOGLIKEGRADIENTS Gradient of MULTIMODEL model log likelihood with respect to parameters.
% MODELOBJECTIVE Objective function to minimise for given model.
% SPECTRUMMODIFY Helper code for visualisation of spectrum data.
% KPCAEMBED Embed data set with kernel PCA.
% DEMMPPCA1 Demonstrate MPPCA on a artificial dataset.
% MODELPOINTLOGLIKELIHOOD Compute the log likelihood of a given point.
% RBFDISPLAY Display an RBF network.
% KBRCREATE Create a KBR model.
% RBFPERIODICLOGLIKEGRADIENTS Gradient of RBFPERIODIC model log likelihood with respect to parameters.
% LINEARLOGLIKEGRADIENTS Linear model gradients.
% MODELHESSIAN Hessian of error function to minimise for given model.
% KBREXTRACTPARAM Extract parameters from the KBR model structure.
% LINEARDISPLAY Display a linear model.
% MOGUPDATECOVARIANCE Update the covariances of an MOG model.
