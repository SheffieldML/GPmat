function g = mlpBackPropagate(net, x, z, deltas)
