function t = traceProduct(A, B)

% TRACEPRODUCT Returns the trace of the product of two matrices.
%
% t = traceProduct(A, B)
%

% Copyright (c) 2006 Neil D. Lawrence
% traceProduct.m version 1.1



t = sum(sum(A.*B'));