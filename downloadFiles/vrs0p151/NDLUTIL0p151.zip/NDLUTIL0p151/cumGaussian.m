function y = cumGaussian(x)

% CUMGAUSSIAN Cumulative distribution for Gaussian.
%
% y = cumGaussian(x)
%

% Copyright (c) 2006 Neil D. Lawrence
% cumGaussian.m version 1.1



y = 0.5*(1+erf(sqrt(2)/2*x));
