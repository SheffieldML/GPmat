function [ld, UC] = logdet(A, UC)

% LOGDET The log of the determinant when argument is positive definite.
%
% [ld, UC] = logdet(A, UC)
%

% Copyright (c) 2006 Neil D. Lawrence
% logdet.m version 1.2



if nargin < 2
  UC=[];
end

% Obtain a Cholesky decomposition.
if isempty(UC)
  UC = jitChol(A);
end

ld = 2*sum(log(diag(UC)));
