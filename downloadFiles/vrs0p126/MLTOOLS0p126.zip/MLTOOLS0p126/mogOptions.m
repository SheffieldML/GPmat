function options = mogOptions(numComp)

% MOGOPTIONS Sets the default options structure for MOG models.
%
%	Description:
%
%	OPTIONS = MOGOPTIONS(NUMCOMPONENTS) sets the default options
%	structure for mixtures of Gaussians models.
%	 Returns:
%	  OPTIONS - structure containing the default options.
%	 Arguments:
%	  NUMCOMPONENTS - number of components in the mixture model.
%	
%
%	See also
%	MOGCREATE


%	Copyright (c) 2006 Neil D. Lawrence
% 	mogOptions.m version 1.1


options.numComponents = numComp;
options.covtype = 'ppca';