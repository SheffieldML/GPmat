function model = mlpExpandParam(model, params)

% MLPEXPANDPARAM Update mlp model with new vector of parameters.
%
%	Description:
%
%	MODEL = MLPEXPANDPARAM(MODEL, PARAMS) takes a vector of MLP weights
%	and places them in their respective positions in the MLP model. The
%	function is a wrapper for the mlpunpak command.
%	 Returns:
%	  MODEL - the model with the weights distributed in the correct
%	   places.
%	 Arguments:
%	  MODEL - the model in which the weights are to be placed.
%	  PARAMS - a vector of the weights to be placed in the model.
%	
%
%	See also
%	MLPUNPAK, MLPCREATE, MLPEXTRACTPARAM


%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpExpandParam.m version 1.4


model = mlpunpak(model, params);