function model = rbfExpandParam(model, params)

% RBFEXPANDPARAM Update rbf model with new vector of parameters.
%
%	Description:
%	model = rbfExpandParam(model, params)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	rbfExpandParam.m version 1.3


model = rbfunpak(model, params);