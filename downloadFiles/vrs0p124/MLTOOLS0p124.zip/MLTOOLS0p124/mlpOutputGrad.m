function g = mlpOutputGrad(model, X)

% MLPOUTPUTGRAD Evaluate derivatives of mlp model outputs with respect to parameters.
%
%	Description:
%
%	G = MLPOUTPUTGRAD(MODEL, X) evaluates the derivates of a multi-layer
%	perceptron's outputs with respect to the parameters of the
%	multi-layer perceptron. Currently it simply wraps the NETLAB
%	mlpderiv function.
%	 Returns:
%	  G - the gradient of the outputs of the multi-layer perceptron with
%	   respect to each of the parameters. The size of the matrix is
%	   number of data x number of parameters x number of outputs of the
%	   model.
%	 Arguments:
%	  MODEL - the model for which the derivatives are to be computed.
%	  X - the input data locations where the gradients are to be
%	   computed.
%	
%
%	See also
%	MLPCREATE, MLPDERIV


%	Copyright (c) 2006 Neil D. Lawrence
% 	mlpOutputGrad.m version 1.3


g = mlpderiv(model, X);