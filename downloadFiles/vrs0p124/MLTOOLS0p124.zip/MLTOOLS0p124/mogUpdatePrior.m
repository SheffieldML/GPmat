function model = mogUpdatePrior(model)

% MOGUPDATEPRIOR Update the priors of an MOG model.
%
%	Description:
%
%	MODEL = MOGUPDATEPRIOR(MODEL) updates the prior probabilities of a
%	mixtures of Gaussians model.
%	 Returns:
%	  MODEL - the model with updated priors.
%	 Arguments:
%	  MODEL - the model which is to be updated.
%	
%
%	See also
%	MOGCREATE, MOGUPDATEMEAN, MOGUPDATECOVARIANCE, MOGESTEP


%	Copyright (c) 2006 Neil D. Lawrence
% 	mogUpdatePrior.m version 1.1


model.prior = mean(model.posterior);

