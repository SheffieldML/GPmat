function Y = modelOut(model, X)

% MODELOUT Give the output of a model for given X.
%
%	Description:
%
%	Y = MODELOUT(MODEL, X) gives the output of the model for a given
%	input X. For latent variable models it gives a position in data
%	space given a position in latent space.
%	 Returns:
%	  Y - output location(s) corresponding to given input locations.
%	 Arguments:
%	  MODEL - structure specifying the model.
%	  X - input location(s) for which output is to be computed.
%	
%
%	See also
%	MODELCREATE


%	Copyright (c) 2005, 2006 Neil D. Lawrence
% 	modelOut.m version 1.3


fhandle = str2func([model.type 'Out']);
Y = fhandle(model, X);