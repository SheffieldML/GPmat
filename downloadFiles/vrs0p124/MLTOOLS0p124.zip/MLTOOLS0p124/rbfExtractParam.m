function params = rbfExtractParam(model)

% RBFEXTRACTPARAM Wrapper for NETLAB's rbfpak.
%
%	Description:
%	params = rbfExtractParam(model)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	rbfExtractParam.m version 1.3


params = rbfpak(model);