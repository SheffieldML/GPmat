function [model, lbls] = ppcaLoadResult(dataSet, number)

% PPCALOADRESULT Load a previously saved result.
%
%	Description:
%
%	MODEL = PPCALOADRESULT(DATASET, NUMBER) loads a previously saved
%	PPCA result.
%	 Returns:
%	  MODEL - the saved model.
%	 Arguments:
%	  DATASET - the name of the data set to load.
%	  NUMBER - the number of the PPCA run to load.
%	
%
%	See also
%	PPCALOADRESULT


%	Copyright (c) 2009 Neil D. Lawrence
% 	ppcaLoadResult.m SVN version 536
% 	last update 2009-09-30T08:56:53.000000Z

  [Y, lbls] = lvmLoadData(dataSet);

  dataSet(1) = upper(dataSet(1));
  load(['dem' dataSet 'Ppca' num2str(number)])
  model = ppcaReconstruct(ppcaInfo, Y);
end