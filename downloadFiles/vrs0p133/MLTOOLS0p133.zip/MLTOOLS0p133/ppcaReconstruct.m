function model = ppcaReconstruct(mapping, ppcaInfo, y)

% PPCARECONSTRUCT Reconstruct an PPCA form component parts.
%
%	Description:
%
%	MODEL = PPCARECONSTRUCT(KERN, NOISE, PPCAINFO, X, Y) takes component
%	parts of an PPCA model and reconstructs the PPCA model. The
%	component parts are normally retrieved from a saved file.
%	 Returns:
%	  MODEL - an PPCA model structure that combines the component parts.
%	 Arguments:
%	  KERN - a kernel structure for the PPCA.
%	  NOISE - a noise structure for the PPCA (currently ignored).
%	  PPCAINFO - the active set and other information stored in a
%	   structure.
%	  X - the input training data for the PPCA.
%	  Y - the output target training data for the PPCA.
%	
%
%	See also
%	PPCADECONSTRUCT, PPCACREATE


%	Copyright (c) 2009 Neil D. Lawrence
% 	ppcaReconstruct.m SVN version 536
% 	last update 2009-09-30T08:55:19.000000Z

  model = ppcaInfo;
  model.y = y;
    
end
