function model = modelLoadResult(type, dataSet, number)

% MODELLOADRESULT Load a previously saved result.
%
%	Description:
%
%	MODEL = MODELLOADRESULT(TYPE, DATASET, NUMBER) loads a previously
%	saved model result.
%	 Returns:
%	  MODEL - the saved model.
%	 Arguments:
%	  TYPE - the type of model to load.
%	  DATASET - the name of the data set to load.
%	  NUMBER - the number of the model run to load.
%	
%
%	See also
%	MODELLOADRESULT


%	Copyright (c) 2009 Neil D. Lawrence
% 	modelLoadResult.m SVN version 
% 	last update 

  fhandle = [type 'LoadResult'];
  if exist(fhandle)==2
    fhandle = str2func(fhandle);
    model = fhandle(dataSet, number);
  else
    dataSet(1) = upper(dataSet(1));
    type(1) = upper(type(1));
    fileName = ['dem' dataSet type num2str(number)];
    load(fileName);
  end
end