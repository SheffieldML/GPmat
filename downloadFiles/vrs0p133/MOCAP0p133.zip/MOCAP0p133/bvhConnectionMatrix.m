function connection = bvhConnectionMatrix(skel);

% BVHCONNECTIONMATRIX Compute the connection matrix for the structure.
%
%	Description:
%	connection = bvhConnectionMatrix(skel);
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	bvhConnectionMatrix.m version 1.2


connection = skelConnectionMatrix(skel);

