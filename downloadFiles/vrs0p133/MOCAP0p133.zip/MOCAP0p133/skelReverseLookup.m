function index = skelReverseLookup(skel, jointName)

% SKELREVERSELOOKUP Return the number associated with the joint name.
%
%	Description:
%	index = skelReverseLookup(skel, jointName)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	skelReverseLookup.m version 1.1


for i=1:length(skel.tree)
  if strcmp(skel.tree(i).name, jointName)
    index = i;
    return
  end
end

error('Reverse look up of name failed.')
