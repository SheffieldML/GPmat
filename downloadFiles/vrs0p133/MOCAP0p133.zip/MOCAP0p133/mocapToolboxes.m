
% MOCAPTOOLBOXES Toolboxes required by the MOCAP toolbox.
%
%	Description:
%	

%	Copyright (c) 2007 Neil D. Lawrence
% 	mocapToolboxes.m version 1.1

