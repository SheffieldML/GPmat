function bvhPlayData(skel, channels, frameLength)

% BVHPLAYDATA Play bvh motion capture data.
%
%	Description:
%	bvhPlayData(skel, channels, frameLength)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	bvhPlayData.m version 1.1


skelPlayData(skel, channels, frameLength);