% MOCAP toolbox
% Version 0.133		04-Mar-2007
% Copyright (c) 2007 Neil D. Lawrence
% 
% ACCLAIM2XYZ Compute XYZ values given skeleton structure and channels.
% ACCLAIMLOADCHANNELS Load the channels from an AMC file.
% ACCLAIMPLAYFILE Play motion capture data from a asf and amc file.
% ACCLAIMREADSKEL Reads an ASF file into a skeleton structure.
% BVH2XYZ Compute XYZ values given structure and channels.
% BVHCONNECTIONMATRIX Compute the connection matrix for the structure.
% BVHMODIFY Helper code for visualisation of bvh data.
% BVHPLAYDATA Play bvh motion capture data.
% BVHPLAYFILE Play motion capture data from a bvh file.
% BVHREADFILE Reads a bvh file into a tree structure.
% BVHVISUALISE For updating a bvh representation of 3-D data.
% BVHWRITEFILE Write a bvh file from a given structure and channels.
% MOCAPRESULTSCPPBVH Load results from cpp file and visualise as a bvh format.
% MOCAPTOOLBOXES Toolboxes required by the MOCAP toolbox.
% ROTATIONMATRIX Compute the rotation matrix for an angle in each direction.
% SKEL2XYZ Compute XYZ values given skeleton structure and channels.
% SKELCONNECTIONMATRIX Compute the connection matrix for the structure.
% SKELMODIFY Update visualisation of skeleton data.
% SKELPLAYDATA Play skel motion capture data.
% SKELREVERSELOOKUP Return the number associated with the joint name.
% SKELVISUALISE For drawing a skel representation of 3-D data.
% SMOOTHANGLECHANNELS Try and remove artificial discontinuities associated with angles.
% STICKMODIFY Helper code for visualisation of a stick man.
% STICKVISUALISE For updateing a stick representation of 3-D data.
