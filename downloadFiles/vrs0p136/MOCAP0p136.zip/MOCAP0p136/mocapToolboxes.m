
% MOCAPTOOLBOXES Toolboxes required by the MOCAP toolbox.
%
%	Description:
%	% 	mocapToolboxes.m CVS version 1.2
% 	mocapToolboxes.m SVN version 30
% 	last update 2008-01-12T11:32:50.000000Z
