function g = kbrOutputGrad(model, X)

% KBROUTPUTGRAD Evaluate derivatives of kernel based regression model outputs with respect to parameters.
%
% g = kbrOutputGrad(model, X)
%

% Copyright (c) 2005 Neil D. Lawrence
% kbrOutputGrad.m version 1.1




numData = size(X, 1);
g(:, :, 1) = [model.K zeros(size(model.K)) ones(numData, 1) ...
                    zeros(numData, 1)];
g(:, :, 2) = [zeros(size(model.K)) model.K zeros(numData, 1) ...
                    ones(numData, 1)];
