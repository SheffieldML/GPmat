function g = rbfOutputGrad(model, X)

% RBFOUTPUTGRAD Evaluate derivatives of rbf model outputs with respect to parameters.
%
% g = rbfOutputGrad(model, X)
%

% Copyright (c) 2005 Neil D. Lawrence
% rbfOutputGrad.m version 1.1


g = rbfderiv(model, X);