function returnVal = lvmTwoDPlot(X, label, symbol)

% LVMTWODPLOT Helper function for plotting the labels in 2-D.
%
% returnVal = lvmTwoDPlot(X, label, symbol)
%

% Copyright (c) 2005 Neil D. Lawrence
% lvmTwoDPlot.m version 



returnVal = [];

if ~isempty(label)
  for i = 1:size(X, 1)
    labelNo = find(label(i, :));
    try 
      returnVal = [returnVal; plot(X(i, 1), X(i, 2), symbol{labelNo})];
    catch
      if strcmp(lasterr, 'Index exceeds matrix dimensions.')
	error(['Only ' num2str(length(symbol)) ' labels supported (it''s easy to add more!)'])
      end
    end
  end
else
  returnVal = plot(X(:, 1), X(:, 2), 'rx');
end