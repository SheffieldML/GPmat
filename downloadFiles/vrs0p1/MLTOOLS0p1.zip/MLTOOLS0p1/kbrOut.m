function Y = kbrOut(model, X);

% KBROUT Obtain the output of the kernel based regression model.
%
% Y = kbrOut(model, X);
%

% Copyright (c) 2005 Neil D. Lawrence
% kbrOut.m version 1.1



numData = size(X, 1);
Y = kernCompute(model.kern, X, model.X)*model.A+ones(numData, 1)*model.b;
