function Y = rbfOut(model, X);

% RBFOUT Output of an RBF model (wrapper for the NETLAB function rbffwd).
%
% Y = rbfOut(model, X);
%

% Copyright (c) 2005 Neil D. Lawrence
% rbfOut.m version 1.1



Y = rbffwd(model, X);