function handle = vectorVisualise(vals)

% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
%
% handle = vectorVisualise(vals)
%

% Copyright (c) 2005 Neil D. Lawrence
% vectorVisualise.m version 1.1



handle = plot(vals);
