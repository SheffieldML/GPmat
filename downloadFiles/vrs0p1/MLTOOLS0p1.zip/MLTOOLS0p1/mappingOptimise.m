function model = mappingOptimise(model, X, Y, varargin)

% MAPPINGOPTIMISE Optimise the given model.
%
% model = mappingOptimise(model, X, Y, varargin)
%

% Copyright (c) 2005 Neil D. Lawrence
% mappingOptimise.m version 1.1



fhandle = str2func([model.type 'Optimise']);
model = fhandle(model, X, Y, varargin{:});