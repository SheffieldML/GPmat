% MLTOOLS toolbox
% Version 0.1		Tuesday 29 Nov 2005 at 15:41
% Copyright (c) 2005 Neil D. Lawrence
% 
% IMAGEVISUALISE Helper code for showing an image during 2-D visualisation.
% ISOMAPEMBED Embed data set with Isomap.
% KBRCREATE Create a kernel based regression model.
% KBREXPANDPARAM Update kernel based regression model with vector of parameters.
% KBREXTRACTPARAM Extract weights from a kernel based regression model.
% KBROPTIMISE Optimise a kernel based regression.
% KBROUT Obtain the output of the kernel based regression model.
% KBROUTPUTGRAD Evaluate derivatives of kernel based regression model outputs with respect to parameters.
% KPCAEMBED Embed data set with kernel PCA.
% LINEARCREATE Create a linear model.
% LINEAREXPANDPARAM Update linear model with vector of parameters.
% LINEAREXTRACTPARAM Extract weights from a linear model.
% LINEAROPTIMISE Optimise a linear model.
% LINEAROUT Obtain the output of the linear model.
% LINEAROUTPUTGRAD Evaluate derivatives of linear model outputs with respect to parameters.
% LVMCLASSVISUALISE Callback function for visualising data in 2-D.
% LVMSCATTERPLOT 2-D scatter plot of the latent points.
% LVMTWODPLOT Helper function for plotting the labels in 2-D.
% MAPPINGOPTIMISE Optimise the given model.
% MLPCREATE Wrapper for NETLAB's mlp `net'.
% MLPEXPANDPARAMS Update mlp model with new vector of parameters.
% MLPEXTRACTPARAMS Wrapper for NETLAB's mlppak.
% MLPOPTIMISE Optimise MLP for given inputs and outputs.
% MLPOUT Output of an MLP model (wrapper for the NETLAB function mlpfwd).
% MLPOUTPUTGRAD Evaluate derivatives of mlp model outputs with respect to parameters.
% MODELEXPANDPARAM Update a model structure with parameters.
% MODELEXTRACTPARAM Extract the parameters of a model.
% MODELOPTIMISE Optimise the given model.
% MODELOUT Give the output of a model for given X.
% MODELOUTPUTGRAD Compute derivatives with respect to params of model outputs.
% PPCAEMBED Embed data set with Isomap.
% RBFCREATE Wrapper for NETLAB's rbf `net'.
% RBFEXPANDPARAMS Update rbf model with new vector of parameters.
% RBFEXTRACTPARAMS Wrapper for NETLAB's rbfpak.
% RBFOPTIMISE Optimise RBF for given inputs and outputs.
% RBFOUT Output of an RBF model (wrapper for the NETLAB function rbffwd).
% RBFOUTPUTGRAD Evaluate derivatives of rbf model outputs with respect to parameters.
% SPECTRUMMODIFY Helper code for visualisation of spectrum data.
% SPECTRUMVISUALISE Helper code for showing an spectrum during 2-D visualisation.
% VECTORMODIFY Helper code for visualisation of vectorial data.
% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
