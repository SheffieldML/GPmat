function Y = mlpOut(model, X);

% MLPOUT Output of an MLP model (wrapper for the NETLAB function mlpfwd).
%
% Y = mlpOut(model, X);
%

% Copyright (c) 2005 Neil D. Lawrence
% mlpOut.m version 1.1



Y = mlpfwd(model, X);