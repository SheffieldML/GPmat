function params = rbfExtractParam(model)

% RBFEXTRACTPARAMS Wrapper for NETLAB's rbfpak.
%
% params = rbfExtractParam(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% rbfExtractParam.m version 1.1



params = rbfpak(model);