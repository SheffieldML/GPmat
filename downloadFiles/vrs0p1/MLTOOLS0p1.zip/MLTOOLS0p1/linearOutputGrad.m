function g = linearOutputGrad(model, X)

% LINEAROUTPUTGRAD Evaluate derivatives of linear model outputs with respect to parameters.
%
% g = linearOutputGrad(model, X)
%

% Copyright (c) 2005 Neil D. Lawrence
% linearOutputGrad.m version 1.1



numData = size(X, 1);
g(:, :, 1) = [X zeros(size(X)) ones(numData, 1) ...
                    zeros(numData, 1)];
g(:, :, 2) = [zeros(size(X)) X zeros(numData, 1) ...
                    ones(numData, 1)];
