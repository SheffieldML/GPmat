function params = modelExtractParam(model)

% MODELEXTRACTPARAM Extract the parameters of a model.
%
% params = modelExtractParam(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% modelExtractParam.m version 1.1



fhandle = str2func([model.type 'ExtractParam']);
params = fhandle(model);