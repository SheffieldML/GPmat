function model = mlpCreate(inputDim, outputDim, hiddenDim, activeFunc)

% MLPCREATE Wrapper for NETLAB's mlp `net'.
%
% model = mlpCreate(inputDim, outputDim, hiddenDim, activeFunc)
%

% Copyright (c) 2005 Neil D. Lawrence
% mlpCreate.m version 1.1



if nargin < 5
  hiddenDim = 20;
  if nargin < 4
    activeFunc = 'linear';
  end
end

model = mlp(inputDim, hiddenDim, outputDim, activeFunc);
model.numParams = model.nwts;
model.inputDim = inputDim;
model.outputDim = outputDim;
