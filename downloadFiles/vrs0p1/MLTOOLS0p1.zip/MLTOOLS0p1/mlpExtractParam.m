function params = mlpExtractParam(model)

% MLPEXTRACTPARAMS Wrapper for NETLAB's mlppak.
%
% params = mlpExtractParam(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% mlpExtractParam.m version 1.1



params = mlppak(model);