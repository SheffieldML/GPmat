function params = linearExtractParam(model);

% LINEAREXTRACTPARAM Extract weights from a linear model.
%
% params = linearExtractParam(model);
%

% Copyright (c) 2005 Neil D. Lawrence
% linearExtractParam.m version 1.1



params = [model.W(:)' model.b];