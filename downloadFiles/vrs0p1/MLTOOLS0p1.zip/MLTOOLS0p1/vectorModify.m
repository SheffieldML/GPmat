function handle = vectorModify(handle, values)

% VECTORMODIFY Helper code for visualisation of vectorial data.
%
% handle = vectorModify(handle, values)
%

% Copyright (c) 2005 Neil D. Lawrence
% vectorModify.m version 1.1



set(handle, 'YData', values);
