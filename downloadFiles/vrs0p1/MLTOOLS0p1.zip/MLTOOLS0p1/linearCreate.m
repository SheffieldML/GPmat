function model = linearCreate(inputDim, outputDim)

% LINEARCREATE Create a linear model.
%
% model = linearCreate(inputDim, outputDim)
%

% Copyright (c) 2005 Neil D. Lawrence
% linearCreate.m version 1.1



model.type = 'linear';
model.inputDim = inputDim;
model.outputDim = outputDim;
model.numParams = (inputDim + 1)*outputDim;


model.W = randn(inputDim, outputDim)/sqrt(inputDim+1);
model.b = randn(1, outputDim)/sqrt(inputDim+1);
