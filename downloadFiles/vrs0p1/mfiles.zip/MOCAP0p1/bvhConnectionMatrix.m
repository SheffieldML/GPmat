function connection = bvhConnectionMatrix(bvhStruct);

% BVHCONNECTIONMATRIX Compute the connection matrix for the structure.
%
% connection = bvhConnectionMatrix(bvhStruct);

% Copyright (c) 2005 Neil D. Lawrence
% MOCAP toolbox version 0.1



connection = zeros(length(bvhStruct));
for i = 1:length(bvhStruct);
  for j = 1:length(bvhStruct(i).children)    
    connection(i, bvhStruct(i).children(j)) = 1;
  end
end

