function bvhWriteFile(fileName, bvhStruct, channels, frameLength)

% BVHWRITEFILE Write a bvh file from a given structure and channels.
%
% bvhWriteFile(fileName, bvhStruct, channels, frameLength)

% Copyright (c) 2005 Neil D. Lawrence
% MOCAP toolbox version 0.1



if nargin < 4
  frameLength = 0.03333;
end

global SAVECHANNELS
SAVECHANNELS = [];

fid = fopen(fileName, 'w');
depth = 0;
printedNodes = [];
fprintf(fid, 'HIERARCHY\n')
i = 1;
while ~any(printedNodes==i)
  printedNodes = printNode(fid, 1, bvhStruct, printedNodes, depth, channels);
end
fprintf(fid, 'MOTION\n')
fprintf(fid, 'Frames: %d\n', size(channels, 1));
fprintf(fid, 'Frame Time: %2.6f\n', frameLength);
for i = 1:size(channels, 1)
  for j = 1:size(channels, 2)
    fprintf(fid, '%2.4f ', SAVECHANNELS(i, j));
  end
  fprintf(fid, '\n');
end
fclose(fid);



function printedNodes = printNode(fid, j, bvhStruct, printedNodes, ...
                                  depth, channels);

% PRINTNODE Print out the details from the given node.

global SAVECHANNELS

prePart = computePrePart(depth);
if depth > 0
  if strcmp(bvhStruct(j).name, 'Site')
    fprintf(fid, [prePart 'End Site\n']);
  else
    fprintf(fid, [prePart 'JOINT %s\n'], bvhStruct(j).name);
  end
else
  fprintf(fid, [prePart 'ROOT %s\n'], bvhStruct(j).name);
end
fprintf(fid, [prePart '{\n']);
depth = depth + 1;
prePart = computePrePart(depth);
fprintf(fid, [prePart 'OFFSET %2.4f %2.4f %2.4f\n'], ...
        bvhStruct(j).offset(1), ...
        bvhStruct(j).offset(2), ...
        bvhStruct(j).offset(3));
if ~strcmp(bvhStruct(j).name, 'Site')
  fprintf(fid, [prePart 'CHANNELS %d'], length(bvhStruct(j).channels));
  if any(strcmp('Xposition', bvhStruct(j).channels))
    SAVECHANNELS = [SAVECHANNELS channels(:, bvhStruct(j).posInd(1))];
    fprintf(fid, ' Xposition');
  end
  if any(strcmp('Yposition', bvhStruct(j).channels))
    SAVECHANNELS = [SAVECHANNELS channels(:, bvhStruct(j).posInd(2))];
    fprintf(fid, ' Yposition');
  end
  if any(strcmp('Zposition', bvhStruct(j).channels))
    SAVECHANNELS = [SAVECHANNELS channels(:, bvhStruct(j).posInd(3))];
    fprintf(fid, ' Zposition');
  end
  if any(strcmp('Zrotation', bvhStruct(j).channels))
    SAVECHANNELS = [SAVECHANNELS channels(:, bvhStruct(j).rotInd(3))];
    fprintf(fid, ' Zrotation');
  end
  if any(strcmp('Xrotation', bvhStruct(j).channels))
    SAVECHANNELS = [SAVECHANNELS channels(:, bvhStruct(j).rotInd(1))];
    fprintf(fid, ' Xrotation');
  end
  if any(strcmp('Yrotation', bvhStruct(j).channels))
    SAVECHANNELS = [SAVECHANNELS channels(:, bvhStruct(j).rotInd(2))];
    fprintf(fid, ' Yrotation');
  end
  fprintf(fid, '\n');
end
  
% print out channels
printedNodes = j;
for i = bvhStruct(j).children
  printedNodes = [printedNodes printNode(fid, i, bvhStruct, printedNodes, ...
                                         depth, channels)];
end
depth = depth - 1;
prePart = computePrePart(depth);
fprintf(fid, [prePart '}\n']);


function prePart = computePrePart(depth);

prePart = [];
for i = 1:depth
  prePart = [prePart '\t'];
end
