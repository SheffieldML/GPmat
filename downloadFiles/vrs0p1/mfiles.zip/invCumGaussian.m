function y = invCumGaussian(x)

% INVCUMGAUSSIAN Inverser of the cumulative Gaussian.
%
% y = invCumGaussian(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:30:10 2004
% NDLUTIL toolbox version 0.1






y = erfinv(x*2 - 1)*2/sqrt(2);