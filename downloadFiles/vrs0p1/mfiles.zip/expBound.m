function y = expBound(x, transform)

% EXPBOUND Constrains a parameter to be positive through exponentiation.
%
% y = expBound(x, transform)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Apr 15 23:36:09 2004
% OPTIMI toolbox version 0.1



limVal = 36;
switch transform
 case 'atox'
  index = find(x<-limVal);
  y(index) = eps;
  x(index) = NaN;
  index = find(x<limVal);
  y(index) = exp(x(index));
  x(index) = NaN;
  index = find(~isnan(x));
  if ~isempty(index)
    y(index) = exp(limVal);
  end
 case 'xtoa'
  y = log(x);
 case 'gradfact'
  y = x;
end
