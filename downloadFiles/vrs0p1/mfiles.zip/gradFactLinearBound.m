function y = gradFactLinearBound(x)

% GRADFACTLINEARBOUND Gradient multiplier for linear bound.
%
% y = gradFactLinearBound(x)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.1, Thu Apr 22 02:42:48 2004
% OPTIMI toolbox version 0.1




limVal = 36;
index = find(x>limVal);
y(index) = 1;
index = find(x<=limVal);
y(index) = (exp(x(index))-1)./exp(x(index));
