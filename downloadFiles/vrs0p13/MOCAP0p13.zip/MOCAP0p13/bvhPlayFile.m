function bvhPlayFile(fileName)

% BVHPLAYFILE Play motion capture data from a bvh file.
%
% bvhPlayFile(fileName)
%

% Copyright (c) 2006 Neil D. Lawrence
% bvhPlayFile.m version 1.2



[skel, channels, frameLength] = bvhReadFile(fileName);
skelPlayData(skel, channels, frameLength);
