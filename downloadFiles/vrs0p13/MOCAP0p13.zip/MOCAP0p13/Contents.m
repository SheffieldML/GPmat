% MOCAP toolbox
% Version 0.13		Wednesday 22 Feb 2006 at 08:22
% Copyright (c) 2006 Neil D. Lawrence
% 
% SKEL2XYZ Compute XYZ values given skeleton structure and channels.
% ACCLAIMLOADCHANNELS Load the channels from an AMC file.
% ACCLAIMPLAYFILE Play motion capture data from a asf and amc file.
% ACCLAIMREADSKEL Reads an ASF file into a skeleton structure.
% BVH2XYZ Compute XYZ values given structure and channels.
% BVHCONNECTIONMATRIX Compute the connection matrix for the structure.
% BVHMODIFY Helper code for visualisation of bvh data.
% BVHPLAYDATA Play bvh motion capture data.
% BVHPLAYFILE Play motion capture data from a bvh file.
% BVHREADFILE Reads a bvh file into a tree structure.
% BVHVISUALISE For updating a bvh representation of 3-D data.
% BVHWRITEFILE Write a bvh file from a given structure and channels.
% MOCAPRESULTSCPPBVH Load results from cpp file and visualise as a bvh format.
% ROTATIONMATRIX Compute the rotation matrix for an angle in each direction.
% SKEL2XYZ Compute XYZ values given skeleton structure and channels.
% SKELCONNECTIONMATRIX Compute the connection matrix for the structure.
% SKELMODIFY Helper code for visualisation of skel data.
% SKELPLAYDATA Play skel motion capture data.
% SKELREVERSELOOKUP Return the number associated with the joint name.
% SKELVISUALISE For updating a skel representation of 3-D data.
% SMOOTHANGLECHANNELS Try and remove artificial discontinuities associated with angles.
% STICKMODIFY Helper code for visualisation of a stick man.
% STICKVISUALISE For updateing a stick representation of 3-D data.
% TREEFINDCHILDREN Given a tree that lists only parents, add children.
% TREEFINDPARENTS Given a tree that lists only children, add parents.
% TREESWAPNODE Swap two nodes in the tree structure array.
