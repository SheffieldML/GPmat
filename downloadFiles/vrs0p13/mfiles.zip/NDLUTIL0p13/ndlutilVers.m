function [vers, depend] = ndlutilVers

% NDLUTILPATH Brings dependent toolboxes into the path.
%
% [vers, depend] = ndlutilVers

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sun Jan  2 15:49:12 2005
% NDLUTIL toolbox version 0.13



vers = 0.13;
if nargout > 2
  depend = [];
end
