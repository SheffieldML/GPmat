function [area, rocPointX, rocPointY] = rocCurve(outputs, labels)

% ROCCURVE Draw ROC curve and return labels.
%
% [area, rocPointX, rocPointY] = rocCurve(outputs, labels)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jun 12 13:30:10 2004
% NDLUTIL toolbox version 0.13



% GENERAL

[sOutputs, index] = sort(outputs);
sLabels = labels(index);

for i = length(sOutputs):-1:1;
  % False positives
  rocPointX(length(sOutputs)-i+1) = sum(sLabels(i:end)==-1)/sum(labels==-1);
  rocPointY(length(sOutputs)-i+1) = sum(sLabels(i:end)==1)/sum(labels==1);
end

if nargin < 3
  plot(rocPointX, rocPointY);
end
area = trapz(rocPointX, rocPointY);