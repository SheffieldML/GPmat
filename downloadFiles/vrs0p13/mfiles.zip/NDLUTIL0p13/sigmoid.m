function y = sigmoid(x)

% SIGMOID The sigmoid function
%
% y = sigmoid(x)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Thu Jun 17 15:05:19 2004
% NDLUTIL toolbox version 0.13



y = ones(size(x))./(1+exp(-x));