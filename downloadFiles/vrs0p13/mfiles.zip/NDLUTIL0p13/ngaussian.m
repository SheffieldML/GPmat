function y = ngaussian(x)

% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
%
% y = ngaussian(x)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Thu Jun 17 15:06:30 2004
% NDLUTIL toolbox version 0.13



x2 = x.*x;
y = exp(-.5*x2);
y = y/sqrt(2*pi);
