function options = linearOptions;

% LINEAROPTIONS Options for learning a linear model.
%
%	Description:
%	options = linearOptions;
%% 	linearOptions.m CVS version 1.1
% 	linearOptions.m SVN version 24
% 	last update 2011-06-16T07:23:44.000000Z

options.activeFunc = 'linear';