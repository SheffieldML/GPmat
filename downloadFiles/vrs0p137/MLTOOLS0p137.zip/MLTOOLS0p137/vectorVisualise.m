function handle = vectorVisualise(vals)

% VECTORVISUALISE  Helper code for plotting a vector during 2-D visualisation.
%
%	Description:
%	handle = vectorVisualise(vals)
%% 	vectorVisualise.m CVS version 1.2
% 	vectorVisualise.m SVN version 24
% 	last update 2011-06-16T07:23:44.000000Z

handle = plot(vals);
