function handle = plot3Modify(handle, values, Y)

% PLOT3MODIFY Helper code for visualisation of 3-d data.
%
%	Description:
%	handle = plot3Modify(handle, values, Y)
%% 	plot3Modify.m SVN version 1414
% 	last update 2011-06-16T07:23:44.000000Z

set(handle, 'XData', values(1), 'YData', values(2), 'ZData', values(3));
