function options = defaultOptions;

% DEFAULTOPTIONS The default options for optimisation.
%
%	Description:
%	options = defaultOptions;
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	defaultOptions.m version 1.1


options = [0,  1e-4, 1e-4, 1e-6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1e-8, 0.1, 0];