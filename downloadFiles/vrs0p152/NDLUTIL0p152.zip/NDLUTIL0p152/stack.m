function x = stack(X)

% STACK Return column stacked vector of given matrix.
%
%	Description:
%	x = stack(X)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	stack.m version 1.1


x = X(:);