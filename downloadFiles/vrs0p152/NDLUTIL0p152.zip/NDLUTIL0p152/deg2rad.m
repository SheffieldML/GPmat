function theta = deg2rad(omega)

% DEG2RAD Transform degrees to radians.
%
%	Description:
%	theta = deg2rad(omega)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	deg2rad.m version 1.1


theta = omega/180*pi;