function parts = stringSplit(string, separator)

% STRINGSPLIT Return separate parts of a string.
%
%	Description:
%	parts = stringSplit(string, separator)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	stringSplit.m version 1.2


if nargin < 2
  separator = ',';
end

parts = tokenise(string, separator);