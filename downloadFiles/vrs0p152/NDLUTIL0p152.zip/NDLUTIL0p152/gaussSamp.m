function y = gaussSamp(Sigma, numSamps)

% GAUSSSAMP Sample from a Gaussian with a given covariance.
%
%	Description:
%	y = gaussSamp(Sigma, numSamps)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	gaussSamp.m version 1.1


[U, V] = eig(Sigma);
dims = size(Sigma, 1);
y = randn(numSamps, dims);
y = y*diag(sqrt(diag(V)));
y = y*U';