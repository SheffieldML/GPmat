function [Ainv, UC] = pdinv(A, UC)

% PDINV Invert a positive definite matrix.
%
%	Description:
%	[Ainv, UC] = pdinv(A, UC)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	pdinv.m version 1.3


if nargin < 2
  UC=[];
end

% Obtain a Cholesky decomposition.
if isempty(UC)
  UC = jitChol(A);
end

invU = UC\eye(size(A, 1));
%invU = eye(size(A, 1))/UC;
Ainv = invU*invU'; 
