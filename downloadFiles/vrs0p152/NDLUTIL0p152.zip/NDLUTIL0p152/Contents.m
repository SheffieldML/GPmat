% NDLUTIL toolbox
% Version 0.152		Saturday 14 Oct 2006 at 21:59
% Copyright (c) 2006 Neil D. Lawrence
% 
% CUMGAUSSIAN Cumulative distribution for Gaussian.
% DEFAULTOPTIONS The default options for optimisation.
% GAUSSOVERDIFFCUMGAUSSIAN A Gaussian over difference of cumulative Gaussians.
% GAUSSSAMP Sample from a Gaussian with a given covariance.
% GETSYMBOLS Get a cell structure of different plot symbols.
% GETLINE Get a line from a file, but ignore it if it starts with a comment (default #).
% GRADLOGCUMGAUSSIAN Gradient of the log of the cumulative Gaussian.
% INVCUMGAUSSIAN Inverser of the cumulative Gaussian.
% INVSIGMOID The inverse of the sigmoid function.
% LNCUMGAUSSIAN log cumulative distribution for the normalised Gaussian.
% LNDIFFCUMGAUSSIAN Log of the difference between two cumulative Gaussians.
% LOGDET The log of the determinant when argument is positive definite.
% NGAUSSIAN Compute a Gaussian with mean 0 and variance 1.
% NUMSF2STR Convert number to a string with a number of significant digits.
% PDINV Invert a positive definite matrix.
% PREPAREPLOT Helper function for tidying up the plot before printing.
% ROCCURVE Draw ROC curve and return labels.
% SIGMOID The sigmoid function
% STRINGSIGFIGS Convert number to a string with a number of significant digits.
% STRINGSPLIT Return separate parts of a string.
% TABLEREAD Read in data which has column titles in the first line and separated values in each other line.
% TOKENISE Split a string into separate tokens.
% TRACEPRODUCT Returns the trace of the product of two matrices.
% ZEROAXES A function to move the axes crossing point to the origin.
% DEG2RAD Transform degrees to radians.
% SCATTERPLOT 2-D scatter plot of labelled points.
% XLOGY z = x*log(y) returns zero if x=y=0
% JITCHOL Do a Cholesky decomposition, if matrix isn't positive definite add jitter and do it again.
% SPARSEDIAG Create a diagonal matrix that is sparse from a vector.
% STACK Return column stacked vector of given matrix.
% KLDIVGAUSSIAN Give the KL divergence between two Gaussians.
% GRADIENTCHECK Check gradients of objective function.
