
% MOCAPTOOLBOXES Toolboxes required by the MOCAP toolbox.
%
%	Description:
%	% 	mocapToolboxes.m CVS version 1.2
% 	mocapToolboxes.m SVN version 30
% 	last update 2007-03-04T23:36:46.000000Z
